from energetic_molecule_generator import EnergeticMoleculeGenerator


def simple_screening_example():
    print("示例1: 仅对现有分子进行风险筛选（不生成新分子）")
    print("-" * 60)
    
    generator = EnergeticMoleculeGenerator('密度.csv')
    
    results = generator.screen_and_classify(generator.molecules)
    generator.save_results(results, 'screening_only')
    
    return results


def custom_generation_example():
    print("\n示例2: 自定义参数生成虚拟分子库")
    print("-" * 60)
    
    generator = EnergeticMoleculeGenerator('密度.csv')
    
    # 自定义参数
    num_mutations_per_mol = 5  # 每个分子突变5次
    num_combinations = 300     # 生成300个组合分子
    
    virtual_mols = generator.generate_virtual_library(
        num_mutations_per_mol=num_mutations_per_mol,
        num_combinations=num_combinations
    )
    
    all_mols = generator.molecules + virtual_mols
    results = generator.screen_and_classify(all_mols)
    
    generator.save_results(results, 'custom_generation')
    
    return results


def single_molecule_analysis():
    print("\n示例3: 单个分子风险分析")
    print("-" * 60)
    
    generator = EnergeticMoleculeGenerator('密度.csv')
    
    if len(generator.molecules) > 0:
        mol = generator.molecules[0]
        score, factors = generator.calculate_risk_score(mol)
        risk_level = generator.classify_risk(score)
        
        print(f"SMILES: {Chem.MolToSmiles(mol)}")
        print(f"风险评分: {score}")
        print(f"风险等级: {risk_level}")
        print(f"风险因子: {factors}")


def show_command_line_usage():
    print("\n" + "=" * 60)
    print("命令行使用示例")
    print("=" * 60)
    print("""
基本用法：
  python energetic_molecule_generator.py

自定义参数：
  # 每个分子突变5次，生成500个组合分子
  python energetic_molecule_generator.py --mutations 5 --combinations 500
  
  # 每个分子突变10次，生成1000个组合分子，输出到big_library
  python energetic_molecule_generator.py --mutations 10 --combinations 1000 --output big_library
  
  # 仅筛选现有分子，不生成新分子
  python energetic_molecule_generator.py --no-generation
  
  # 使用其他输入文件
  python energetic_molecule_generator.py --input my_molecules.csv
  
  # 完整参数示例
  python energetic_molecule_generator.py --input my_molecules.csv --mutations 3 --combinations 200 --output my_results

查看帮助：
  python energetic_molecule_generator.py --help
    """)


if __name__ == "__main__":
    from rdkit import Chem
    
    print("=" * 60)
    print("含能分子生成与筛选系统 - 使用示例")
    print("=" * 60)
    
    print("\n选择示例运行：")
    print("1. 仅筛选现有分子")
    print("2. 生成并筛选虚拟分子库")
    print("3. 单个分子分析示例")
    print("4. 查看命令行使用方法")
    
    try:
        choice = input("\n请输入选择 (1/2/3/4，默认1): ").strip()
        if choice == '2':
            custom_generation_example()
        elif choice == '3':
            single_molecule_analysis()
        elif choice == '4':
            show_command_line_usage()
        else:
            simple_screening_example()
    except KeyboardInterrupt:
        print("\n操作已取消")
    except Exception as e:
        print(f"\n错误: {e}")
