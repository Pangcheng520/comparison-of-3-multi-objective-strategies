# 含能分子虚拟生成与风险筛选系统

## 概述
本系统基于RDKit，用于含能分子的虚拟生成和风险评估分类。

## 环境要求
- Python 3.7+
- pandas
- RDKit
- tqdm

## 安装依赖
```bash
pip install pandas tqdm
# 或者使用conda安装RDKit: conda install -c conda-forge rdkit pandas tqdm
```

## 文件说明
- `密度.csv`: 输入文件，包含含能分子的SMILES
- `energetic_molecule_generator.py`: 主程序文件
- `example_usage.py`: 使用示例
- `requirements.txt`: 依赖列表

## 使用方法

### 快速开始
直接运行主程序（使用默认参数）：
```bash
python energetic_molecule_generator.py
```

### 命令行参数
您可以通过命令行参数自定义生成虚拟分子的数量：

```bash
# 查看帮助信息
python energetic_molecule_generator.py --help

# 自定义参数示例
# --mutations: 每个分子的突变次数（默认：2）
# --combinations: 组合生成的分子数量（默认：200）
# --output: 输出文件前缀（默认：virtual_library）
# --input: 输入CSV文件路径（默认：密度.csv）
# --no-generation: 仅筛选现有分子，不生成新分子

# 每个分子突变5次，生成500个组合分子
python energetic_molecule_generator.py --mutations 5 --combinations 500

# 每个分子突变10次，生成1000个组合分子
python energetic_molecule_generator.py --mutations 10 --combinations 1000

# 仅筛选现有分子，不生成新分子
python energetic_molecule_generator.py --no-generation

# 完整参数示例
python energetic_molecule_generator.py --input my_molecules.csv --mutations 3 --combinations 200 --output my_results
```

### 运行示例
```bash
python example_usage.py
```

## 主要功能

### 1. 分子生成
- **突变生成**: 对现有分子进行随机突变
  - 添加含能基团（硝基、叠氮基等）
  - 杂原子替换
  - 骨架修饰
- **组合生成**: 随机组合两个现有分子

### 2. 风险评估
风险评分基于以下因素：
- 含能基团种类和数量（硝基、叠氮、硝胺等）
- 氮/氧原子比例
- 氧平衡值
- 分子结构特征

### 3. 风险分类
- **高风险**: 评分 ≥ 40
- **中风险**: 20 ≤ 评分 < 40  
- **低风险**: 评分 < 20

## 输出文件
程序会生成以下CSV文件：
- `original_all.csv`: 原始分子分析结果
- `original_high_risk.csv`: 原始高风险分子
- `original_medium_risk.csv`: 原始中风险分子
- `original_low_risk.csv`: 原始低风险分子
- `virtual_library_all.csv`: 完整虚拟库分析结果
- `virtual_library_high_risk.csv`: 虚拟库高风险分子
- `virtual_library_medium_risk.csv`: 虚拟库中风险分子
- `virtual_library_low_risk.csv`: 虚拟库低风险分子

## 自定义使用
```python
from energetic_molecule_generator import EnergeticMoleculeGenerator

# 初始化生成器
generator = EnergeticMoleculeGenerator('密度.csv')

# 生成虚拟库
virtual_mols = generator.generate_virtual_library(
    num_mutations_per_mol=3,
    num_combinations=100
)

# 筛选和分类
results = generator.screen_and_classify(generator.molecules + virtual_mols)

# 保存结果
generator.save_results(results, 'my_results')
```

## 风险评估因子
系统包含以下含能基团的检测：
- nitro (硝基)
- nitramine (硝胺)
- azide (叠氮)
- furazan (呋咱)
- furoxan (氧化呋咱)
- tetrazole (四唑)
- triazole (三唑)
- nitroso (亚硝基)
- peroxide (过氧化物)
- diazene (偶氮)
