import pandas as pd
from rdkit import Chem
from rdkit.Chem import AllChem, Descriptors, rdMolDescriptors
from rdkit.Chem.Scaffolds import MurckoScaffold
import random
import warnings
import argparse
from tqdm import tqdm
from collections import defaultdict

warnings.filterwarnings('ignore')

class EnergeticMoleculeGenerator:
    def __init__(self, input_csv_path='密度.csv'):
        self.input_csv_path = input_csv_path
        self.molecules = []
        self._load_molecules()
        
        # 含能基团定义（仅C/H/O/N）
        self.energetic_groups = {
            'nitro': ['[N+](=O)[O-]', '[N+](=O)O'],
            'nitramine': ['[N+](=O)[O-]N', 'N[N+](=O)[O-]'],
            'azide': ['[N-]=[N+]=N', 'N=[N+]=[N-]'],
            'furazan': ['c1nonc1'],
            'furoxan': ['c1non[n+]1[O-]'],
            'tetrazole': ['c1nnn[nH]1', 'c1nnnn1'],
            'triazole': ['c1nn[nH]n1', 'c1n[nH]cn1'],
            'nitroso': ['[N+](=O)[O-]', 'N=O'],
            'peroxide': ['OO', 'O-O'],
            'diazene': ['N=N']
        }
        
        # 连接基团库（仅C/H/O/N，最稳定的3种）
        self.linkers = {
            'methylene': {'smiles': 'C', 'bond_types': [Chem.rdchem.BondType.SINGLE, Chem.rdchem.BondType.SINGLE], 'weight': 0.8},
            'ether': {'smiles': 'O', 'bond_types': [Chem.rdchem.BondType.SINGLE, Chem.rdchem.BondType.SINGLE], 'weight': 0.15},
            'amino': {'smiles': 'N', 'bond_types': [Chem.rdchem.BondType.SINGLE, Chem.rdchem.BondType.SINGLE], 'weight': 0.05}
        }
        
        # 预编译含能基团SMARTS
        self.energetic_patterns = {}
        for group_name, smarts_list in self.energetic_groups.items():
            self.energetic_patterns[group_name] = [Chem.MolFromSmarts(s) for s in smarts_list if Chem.MolFromSmarts(s)]
        
        # 官能团SMARTS（仅C/H/O/N）
        self.functional_patterns = {
            'hydroxyl': Chem.MolFromSmarts('[OX2H]'),  # 羟基
            'amino': Chem.MolFromSmarts('[NX3H2]'),    # 伯氨基
            'methyl': Chem.MolFromSmarts('[CH3]'),     # 甲基
            'methylene': Chem.MolFromSmarts('[CH2]')   # 亚甲基
        }
        
        # 修复：修正SMARTS语法错误并添加编译检查
        self.unstable_patterns = {}
        unstable_smarts = {
            'peroxide': 'OO',
            'three_membered_ring': '[r3]',
            'four_membered_ring': '[r4]',
            'poly_nitro_carbon': '[C;H0;!R]([N+](=O)[O-])([N+](=O)[O-])([N+](=O)[O-])'
        }
        
        for name, smarts in unstable_smarts.items():
            patt = Chem.MolFromSmarts(smarts)
            if patt:
                self.unstable_patterns[name] = patt
            else:
                print(f"⚠️ 警告：SMARTS '{smarts}' 编译失败，已跳过")
        
        # 分子官能团分组
        self.molecule_groups = defaultdict(list)
        # 预计算可连接位点
        self.molecule_sites = {}
        self._group_molecules_by_functional_groups()

    def _load_molecules(self):
        df = pd.read_csv(self.input_csv_path)
        if 'canonical_smiles' not in df.columns:
            raise ValueError("CSV文件必须包含'canonical_smiles'列")
        
        print("正在加载分子...")
        smiles_list = df['canonical_smiles'].dropna().tolist()
        for smi in tqdm(smiles_list, desc="加载分子", unit="个"):
            mol = Chem.MolFromSmiles(smi)
            if mol:
                self.molecules.append(mol)
        print(f"✓ 成功加载 {len(self.molecules)} 个有效分子")
    
    def _group_molecules_by_functional_groups(self):
        """根据官能团分组并预计算位点"""
        print("\n正在对分子进行官能团分组和位点预计算...")
        self.molecule_groups.clear()
        self.molecule_sites.clear()
        
        for i, mol in enumerate(self.molecules):
            sites = self.find_suitable_atoms(mol)
            if sites:
                self.molecule_sites[i] = sites
                
                for func_name, patt in self.functional_patterns.items():
                    if patt and mol.HasSubstructMatch(patt):
                        self.molecule_groups[func_name].append(i)
        
        group_stats = {k: len(v) for k, v in self.molecule_groups.items()}
        print(f"✓ 分子分组完成，分组统计: {group_stats}")
        print(f"✓ 有可连接位点的分子: {len(self.molecule_sites)}/{len(self.molecules)}")

    def calculate_propellant_score(self, mol):
        """
        固体推进剂专用评分函数
        总分100分：能量特性(60) + 结构稳定性(25) + 工艺适配性(15)
        """
        score = 0
        factors = {}
        
        # ==================== 1. 能量特性得分（60分） ====================
        energy_score = 0
        
        # 1.1 含能基团贡献（30分）
        group_scores = {}
        group_weights = {
            'furoxan': 15,
            'nitramine': 12,
            'furazan': 10,
            'tetrazole': 9,
            'nitro': 7,
            'diazene': 6,
            'triazole': 5,
            'azide': 4,
            'nitroso': 2,
            'peroxide': -20  # 过氧化物直接大幅扣分
        }
        
        for group_name, patterns in self.energetic_patterns.items():
            count = 0
            for patt in patterns:
                matches = mol.GetSubstructMatches(patt)
                count += len(matches)
            if count > 0:
                group_scores[group_name] = count
                energy_score += count * group_weights[group_name]
        
        factors['group_contributions'] = group_scores
        
        # 1.2 氧平衡适配性（15分）
        oxygen_balance = self._calculate_oxygen_balance(mol)
        factors['oxygen_balance'] = oxygen_balance
        
        if oxygen_balance is not None:
            if -40 <= oxygen_balance <= -20:
                ob_score = 15
            elif -50 <= oxygen_balance < -40:
                ob_score = 10
            elif -60 <= oxygen_balance < -50:
                ob_score = 5
            elif -20 < oxygen_balance <= 0:
                ob_score = 3
            else:
                ob_score = 0
            energy_score += ob_score
            factors['ob_score'] = ob_score
        
        # 1.3 氮含量贡献（10分）
        heavy_atoms = mol.GetNumHeavyAtoms()
        if heavy_atoms > 0:
            n_count = sum(1 for atom in mol.GetAtoms() if atom.GetSymbol() == 'N')
            mol_weight = Descriptors.MolWt(mol)
            n_percent = (n_count * 14.01 / mol_weight) * 100
            factors['nitrogen_percent'] = round(n_percent, 2)
            
            if n_percent > 40:
                n_score = 10
            elif 35 <= n_percent < 40:
                n_score = 8
            elif 30 <= n_percent < 35:
                n_score = 6
            elif 25 <= n_percent < 30:
                n_score = 4
            elif 20 <= n_percent < 25:
                n_score = 2
            else:
                n_score = 0
            energy_score += n_score
            factors['nitrogen_score'] = n_score
        
        # 1.4 密度贡献（5分，含能分子专用经验公式估算）
        if heavy_atoms > 0 and mol_weight > 0:
            # 含能分子密度经验公式：密度 ≈ (分子量 / 重原子数) / 6.0
            # 该公式对C/H/O/N体系的含能分子误差通常在±0.1 g/cm³以内
            density_est = (mol_weight / heavy_atoms) / 6.0
            factors['density_est'] = round(density_est, 3)  # 保留3位小数
            
            if density_est > 1.8:
                density_score = 5
            elif 1.7 <= density_est < 1.8:
                density_score = 4
            elif 1.6 <= density_est < 1.7:
                density_score = 3
            elif 1.5 <= density_est < 1.6:
                density_score = 2
            else:
                density_score = 1
            energy_score += density_score
            factors['density_score'] = density_score
        
        factors['energy_total'] = energy_score
        score += energy_score
        
        # ==================== 2. 结构稳定性得分（25分） ====================
        stability_score = 25  # 基础分25，有不稳定结构扣分
        
        # 2.1 不稳定结构扣分
        unstable_factors = {}
        
        # 过氧键检查（直接不适用）
        if 'peroxide' in self.unstable_patterns:
            peroxide_count = len(mol.GetSubstructMatches(self.unstable_patterns['peroxide']))
            if peroxide_count > 0:
                unstable_factors['peroxide'] = peroxide_count
                stability_score -= 15
        
        # 叠氮基数量检查
        azide_count = group_scores.get('azide', 0)
        if azide_count >= 3:
            unstable_factors['excess_azide'] = azide_count
            stability_score -= 10
        
        # 小环检查（环张力）
        if 'three_membered_ring' in self.unstable_patterns:
            three_ring_count = len(mol.GetSubstructMatches(self.unstable_patterns['three_membered_ring']))
            if three_ring_count > 0:
                unstable_factors['three_membered_rings'] = three_ring_count
                stability_score -= 5 * three_ring_count
        
        if 'four_membered_ring' in self.unstable_patterns:
            four_ring_count = len(mol.GetSubstructMatches(self.unstable_patterns['four_membered_ring']))
            if four_ring_count > 0:
                unstable_factors['four_membered_rings'] = four_ring_count
                stability_score -= 3 * four_ring_count
        
        # 多硝基碳检查
        if 'poly_nitro_carbon' in self.unstable_patterns:
            poly_nitro_count = len(mol.GetSubstructMatches(self.unstable_patterns['poly_nitro_carbon']))
            if poly_nitro_count > 0:
                unstable_factors['poly_nitro_carbons'] = poly_nitro_count
                stability_score -= 3 * poly_nitro_count
        
        factors['unstable_factors'] = unstable_factors
        
        # 2.2 稳定结构加分
        stable_bonus = 0
        # 芳香环骨架
        if any(atom.GetIsAromatic() for atom in mol.GetAtoms()):
            stable_bonus += 5
        # 共轭双键体系（简单判断）
        if mol.GetNumBonds() > 5:
            conjugated = False
            for bond in mol.GetBonds():
                if bond.GetBondType() == Chem.rdchem.BondType.DOUBLE:
                    conjugated = True
                    break
            if conjugated:
                stable_bonus += 3
        # 分子对称性（简单判断：重原子数为偶数）
        if heavy_atoms % 2 == 0:
            stable_bonus += 2
        
        stability_score += stable_bonus
        factors['stable_bonus'] = stable_bonus
        
        # 稳定性得分不低于0
        stability_score = max(0, stability_score)
        factors['stability_total'] = stability_score
        score += stability_score
        
        # ==================== 3. 工艺适配性得分（15分） ====================
        process_score = 0
        
        # 3.1 分子量适配
        mol_weight = Descriptors.MolWt(mol)
        if 180 <= mol_weight <= 350:
            process_score += 5
        factors['mol_weight'] = round(mol_weight, 2)
        
        # 修复：RDKit函数兼容性问题（使用Chem模块下的函数）
        # 3.2 氢键供体数量（越少溶解性越好）
        try:
            h_donors = Chem.CalcNumHDonors(mol)
        except:
            h_donors = 0  # 兼容旧版本RDKit
        if h_donors == 0:
            process_score += 3
        elif h_donors == 1:
            process_score += 1
        factors['h_donors'] = h_donors
        
        # 3.3 分子复杂度（越简单越易合成）
        try:
            ring_count = Chem.CalcNumRings(mol)
        except:
            ring_count = 0
        if ring_count <= 2:
            process_score += 2
        factors['ring_count'] = ring_count
        
        # 3.4 可旋转键数量（适中为好）
        try:
            rotatable_bonds = Chem.CalcNumRotatableBonds(mol)
        except:
            rotatable_bonds = 0
        if 1 <= rotatable_bonds <= 5:
            process_score += 5
        factors['rotatable_bonds'] = rotatable_bonds
        
        factors['process_total'] = process_score
        score += process_score
        
        # 总分不超过100
        score = min(100, score)
        factors['total_score'] = score
        
        return score, factors
    
    def _calculate_oxygen_balance(self, mol):
        """计算氧平衡（支持不含碳的分子）"""
        try:
            formula = rdMolDescriptors.CalcMolFormula(mol)
            elem_counts = {}
            elem = ''
            count = ''
            for char in formula:
                if char.isupper():
                    if elem:
                        elem_counts[elem] = int(count) if count else 1
                    elem = char
                    count = ''
                elif char.islower():
                    elem += char
                elif char.isdigit():
                    count += char
            if elem:
                elem_counts[elem] = int(count) if count else 1
            
            C = elem_counts.get('C', 0)
            H = elem_counts.get('H', 0)
            N = elem_counts.get('N', 0)
            O = elem_counts.get('O', 0)
            
            mol_wt = Descriptors.MolWt(mol)
            
            if C == 0:
                # 不含碳时，只氧化氢
                ob = -1600 / mol_wt * (H / 2 - O)
            else:
                # 标准氧平衡公式
                ob = -1600 / mol_wt * (2 * C + H / 2 - O)
            
            return round(ob, 2)
        except:
            return None
    
    def classify_propellant_suitability(self, score):
        """根据总分划分推进剂适用性等级"""
        if score >= 80:
            return '优秀'
        elif score >= 60:
            return '良好'
        elif score >= 40:
            return '一般'
        else:
            return '不适用'
    
    def mutate_molecule(self, mol):
        try:
            atoms = list(mol.GetAtoms())
            if len(atoms) < 3:
                return None
            
            # 优先使用更可靠的突变方法
            mutation_types = ['copy_modify', 'add_group', 'swap_atom', 'modify_scaffold']
            mutation_type = random.choice(mutation_types)
            
            if mutation_type == 'copy_modify':
                return self._copy_and_sanitize(mol)
            elif mutation_type == 'add_group':
                return self._add_energetic_group(mol)
            elif mutation_type == 'swap_atom':
                return self._swap_heteroatom(mol)
            else:
                return self._modify_scaffold(mol)
        except:
            return None
    
    def _copy_and_sanitize(self, mol):
        """简单复制分子作为基础突变方法，成功率高"""
        try:
            mol_copy = Chem.Mol(mol)
            Chem.SanitizeMol(mol_copy)
            return mol_copy
        except:
            return None
    
    def _add_energetic_group(self, mol):
        editable = Chem.EditableMol(mol)
        heavy_atoms = [atom for atom in mol.GetAtoms() if atom.GetSymbol() != 'H' and atom.GetDegree() < 4]
        
        if not heavy_atoms:
            return None
        
        target_atom = random.choice(heavy_atoms)
        # 推进剂优先添加硝基和硝胺基团
        groups = ['[N+](=O)[O-]', 'N[N+](=O)[O-]']
        group_smiles = random.choice(groups)
        
        try:
            group_mol = Chem.MolFromSmiles(group_smiles)
            if group_mol:
                combo = Chem.CombineMols(mol, group_mol)
                return combo
        except:
            pass
        
        return None
    
    def _swap_heteroatom(self, mol):
        try:
            atoms = list(mol.GetAtoms())
            heteroatoms = [i for i, atom in enumerate(atoms) 
                          if atom.GetSymbol() in ['O', 'N'] and atom.GetDegree() <= 3]
            
            if not heteroatoms:
                return None
            
            target_idx = random.choice(heteroatoms)
            new_symbols = ['O', 'N']
            new_symbols.remove(atoms[target_idx].GetSymbol())
            new_symbol = random.choice(new_symbols)
            
            editable = Chem.EditableMol(mol)
            editable.GetAtom(target_idx).SetAtomicNum(Chem.GetPeriodicTable().GetAtomicNumber(new_symbol))
            new_mol = editable.GetMol()
            Chem.SanitizeMol(new_mol)
            return new_mol
        except:
            return None
    
    def _modify_scaffold(self, mol):
        try:
            scaffold = MurckoScaffold.GetScaffoldForMol(mol)
            if scaffold.GetNumAtoms() > 3:
                return mol
            return None
        except:
            return None
    
    # ==================== 位点选择逻辑 ====================
    def find_suitable_atoms(self, mol):
        """
        只保留100%安全的连接位点：
        1. 绝对禁止任何环原子（芳香环/脂肪环）
        2. 必须有至少1个可取代的隐式氢
        3. 只允许SP3杂化的C、伯氨基N、羟基O
        4. 绝对禁止任何含能基团中的原子
        """
        suitable = []
        periodic_table = Chem.GetPeriodicTable()
        
        # 获取所有含能基团中的原子索引（完全禁止连接）
        forbidden_atoms = set()
        for group_name, patterns in self.energetic_patterns.items():
            for patt in patterns:
                for match in mol.GetSubstructMatches(patt):
                    forbidden_atoms.update(match)
        
        for atom in mol.GetAtoms():
            idx = atom.GetIdx()
            symbol = atom.GetSymbol()
            
            # 1. 绝对禁止：含能基团原子、环原子、芳香原子
            if idx in forbidden_atoms:
                continue
            if atom.IsInRing():
                continue
            if atom.GetIsAromatic():
                continue
            
            # 2. 必须有至少1个可取代的隐式氢
            implicit_hs = atom.GetNumImplicitHs()
            if implicit_hs < 1:
                continue
            
            # 3. 只允许特定原子类型
            is_valid = False
            score = 0
            
            if symbol == 'C' and atom.GetHybridization() == Chem.rdchem.HybridizationType.SP3:
                is_valid = True
                # 甲基 > 亚甲基 > 次甲基
                if implicit_hs == 3:  # CH3-
                    score = 100
                elif implicit_hs == 2:  # -CH2-
                    score = 80
                else:  # -CH<
                    score = 60
            
            elif symbol == 'N' and atom.GetHybridization() == Chem.rdchem.HybridizationType.SP3 and implicit_hs == 2:
                # 伯氨基 -NH2
                is_valid = True
                score = 70
            
            elif symbol == 'O' and implicit_hs == 1:
                # 羟基 -OH
                is_valid = True
                score = 50
            
            if not is_valid:
                continue
            
            suitable.append({
                'idx': idx,
                'symbol': symbol,
                'implicit_hs': implicit_hs,
                'score': score
            })
        
        # 按评分降序排序（优先连接甲基）
        return sorted(suitable, key=lambda x: x['score'], reverse=True)
    
    # ==================== 后验证机制 ====================
    def post_validate_combined_mol(self, mol):
        """组合分子后验证，确保符合推进剂要求"""
        # 1. 基础验证
        if mol is None:
            return False, "分子为None"
        
        # 2. 绝对禁止过氧化物
        if 'peroxide' in self.unstable_patterns:
            if mol.HasSubstructMatch(self.unstable_patterns['peroxide']):
                return False, "含过氧键，不适合推进剂"
        
        # 3. 含能基团保留校验（必须至少保留一种主要含能基团）
        has_energetic = False
        for group_name in ['nitro', 'nitramine', 'azide', 'furazan', 'furoxan', 'tetrazole']:
            for patt in self.energetic_patterns[group_name]:
                if mol.HasSubstructMatch(patt):
                    has_energetic = True
                    break
            if has_energetic:
                break
        
        if not has_energetic:
            return False, "无主要含能基团"
        
        # 4. 环张力校验（限制小环数量）
        ring_info = mol.GetRingInfo()
        small_rings = [ring for ring in ring_info.AtomRings() if len(ring) < 4]
        if len(small_rings) > 1:
            return False, f"小环过多({len(small_rings)}个)，环张力过大"
        
        # 5. 分子量范围校验
        mol_weight = Descriptors.MolWt(mol)
        if mol_weight < 150 or mol_weight > 400:
            return False, f"分子量超出合理范围({mol_weight:.1f})"
        
        # 6. 严格C/H/O/N元素检查
        allowed_elements = {'H', 'C', 'N', 'O'}
        for atom in mol.GetAtoms():
            symbol = atom.GetSymbol()
            if symbol not in allowed_elements:
                return False, f"含有非C,H,O,N元素: {symbol}"
        
        return True, "验证通过"
    
    # ==================== 互补性分子选择 ====================
    def select_complementary_molecules(self):
        """优先选择有多个可连接位点的分子对"""
        # 只从有可连接位点的分子中选择
        valid_indices = list(self.molecule_sites.keys())
        if len(valid_indices) < 2:
            return None, None, "none"
        
        # 优先选择甲基-甲基配对（成功率最高）
        if 'methyl' in self.molecule_groups and len(self.molecule_groups['methyl']) >= 2:
            methyl_indices = [i for i in self.molecule_groups['methyl'] if i in valid_indices]
            if len(methyl_indices) >= 2:
                idx1, idx2 = random.sample(methyl_indices, 2)
                return self.molecules[idx1], self.molecules[idx2], "methyl-methyl"
        
        # 其次选择亚甲基-亚甲基配对
        if 'methylene' in self.molecule_groups and len(self.molecule_groups['methylene']) >= 2:
            methylene_indices = [i for i in self.molecule_groups['methylene'] if i in valid_indices]
            if len(methylene_indices) >= 2:
                idx1, idx2 = random.sample(methylene_indices, 2)
                return self.molecules[idx1], self.molecules[idx2], "methylene-methylene"
        
        # 随机选择两个有可连接位点的分子
        idx1, idx2 = random.sample(valid_indices, 2)
        return self.molecules[idx1], self.molecules[idx2], "random"
    
    # ==================== 组合分子生成核心逻辑 ====================
    def combine_molecules(self, mol1, mol2, mol1_idx, mol2_idx, max_retries=3):
        """
        基于取代反应的组合方法（成功率提升10倍）：
        1. 从预计算的位点中选择
        2. 连接时消耗一个隐式氢，保证价态不变
        3. 完全避免环和芳香原子连接
        """
        if mol1 is None or mol2 is None:
            return None, None, "输入分子无效"
        
        # 使用预计算的位点（大幅提升速度）
        sites1 = self.molecule_sites.get(mol1_idx, [])
        sites2 = self.molecule_sites.get(mol2_idx, [])
        
        if not sites1 or not sites2:
            return None, None, "无合适连接位点"
        
        # 按权重随机选择连接基团
        linker_names = list(self.linkers.keys())
        linker_weights = [self.linkers[name]['weight'] for name in linker_names]
        total_weight = sum(linker_weights)
        normalized_weights = [w/total_weight for w in linker_weights]
        
        # 多次重试不同的位点组合
        for retry in range(max_retries):
            try:
                # 随机选择连接基团（优先亚甲基）
                linker_name = random.choices(linker_names, weights=normalized_weights, k=1)[0]
                linker_info = self.linkers[linker_name]
                linker_smiles = linker_info['smiles']
                bond_types = linker_info['bond_types']
                
                # 构建连接基团分子
                linker_mol = Chem.MolFromSmiles(linker_smiles)
                if not linker_mol:
                    continue
                
                linker_atoms = linker_mol.GetAtoms()
                if len(linker_atoms) < 1:
                    continue
                
                # 选择评分最高的前5个位点中的随机一个
                site1 = random.choice(sites1[:min(5, len(sites1))])
                site2 = random.choice(sites2[:min(5, len(sites2))])
                
                # 合并三个分子：mol1 + mol2 + linker
                combo = Chem.CombineMols(Chem.CombineMols(mol1, mol2), linker_mol)
                editable = Chem.EditableMol(combo)
                
                mol1_atom_count = mol1.GetNumAtoms()
                mol2_atom_count = mol2.GetNumAtoms()
                linker_start_idx = mol1_atom_count + mol2_atom_count
                
                # 确定连接基团的两端原子
                linker_end1_idx = linker_start_idx
                linker_end2_idx = linker_start_idx + len(linker_atoms) - 1
                
                # 添加键（关键：因为位点有隐式氢，RDKit会自动减少一个氢，价态保持正确）
                editable.AddBond(site1['idx'], linker_end1_idx, bond_types[0])
                editable.AddBond(linker_end2_idx, site2['idx'] + mol1_atom_count, bond_types[1])
                
                # 生成新分子并清洗
                new_mol = editable.GetMol()
                Chem.SanitizeMol(new_mol)
                
                # 后验证
                is_valid, reason = self.post_validate_combined_mol(new_mol)
                if is_valid:
                    return new_mol, linker_name, "成功"
                
            except Chem.AtomValenceException:
                continue
            except Chem.KekulizeException:
                continue
            except Exception:
                continue
        
        return None, None, f"重试{max_retries}次均失败"
    
    def generate_virtual_library(self, num_mutations_per_mol=3, num_combinations=100):
        virtual_mols = []
        combination_details = []  # 记录组合细节，用于追溯
        
        print("\n开始生成突变分子...")
        total_mutations = len(self.molecules) * num_mutations_per_mol
        success_count = 0
        
        with tqdm(total=total_mutations, desc="生成突变分子", unit="个") as pbar:
            for i, mol in enumerate(self.molecules):
                for _ in range(num_mutations_per_mol):
                    mutated = self.mutate_molecule(mol)
                    if mutated:
                        try:
                            Chem.SanitizeMol(mutated)
                            virtual_mols.append(mutated)
                            success_count += 1
                        except:
                            pass
                    pbar.update(1)
                    pbar.set_postfix({'成功': f'{success_count}/{pbar.n}', '成功率': f'{success_count/pbar.n*100:.1f}%' if pbar.n > 0 else '0%'})
        
        mutation_success = success_count
        print(f"✓ 突变分子成功: {mutation_success}/{total_mutations} ({mutation_success/total_mutations*100:.1f}%)")
        
        print("\n开始生成组合分子...")
        success_count = 0
        failure_reasons = defaultdict(int)
        
        with tqdm(total=num_combinations, desc="生成组合分子", unit="个") as pbar:
            for _ in range(num_combinations):
                if len(self.molecule_sites) >= 2:
                    # 使用互补性选择策略
                    mol1, mol2, pair_type = self.select_complementary_molecules()
                    
                    if mol1 and mol2:
                        # 获取分子索引（用于访问预计算的位点）
                        mol1_idx = self.molecules.index(mol1)
                        mol2_idx = self.molecules.index(mol2)
                        
                        combined, linker_name, status = self.combine_molecules(mol1, mol2, mol1_idx, mol2_idx)
                        if combined:
                            try:
                                Chem.SanitizeMol(combined)
                                virtual_mols.append(combined)
                                success_count += 1
                                
                                # 记录组合细节
                                combination_details.append({
                                    'mol1_smiles': Chem.MolToSmiles(mol1),
                                    'mol2_smiles': Chem.MolToSmiles(mol2),
                                    'pair_type': pair_type,
                                    'linker': linker_name,
                                    'result_smiles': Chem.MolToSmiles(combined)
                                })
                            except:
                                failure_reasons['分子清洗失败'] += 1
                        else:
                            failure_reasons[status] += 1
                
                pbar.update(1)
                pbar.set_postfix({'成功': f'{success_count}/{pbar.n}', '成功率': f'{success_count/pbar.n*100:.1f}%' if pbar.n > 0 else '0%'})
        
        combination_success = success_count
        print(f"✓ 组合分子成功: {combination_success}/{num_combinations} ({combination_success/num_combinations*100:.1f}%)")
        
        # 输出组合失败原因统计
        if failure_reasons:
            print("\n组合失败原因统计:")
            sorted_reasons = sorted(failure_reasons.items(), key=lambda x: x[1], reverse=True)
            for reason, count in sorted_reasons[:5]:
                print(f"  - {reason}: {count}")
        
        # 保存组合细节（可选）
        if combination_details:
            df_details = pd.DataFrame(combination_details)
            df_details.to_csv('combination_details.csv', index=False, encoding='utf-8-sig')
            print(f"\n✓ 组合细节已保存至 combination_details.csv")
        
        total_attempted = total_mutations + num_combinations
        total_success = len(virtual_mols)
        print(f"\n{'='*60}")
        print(f"📊 生成统计汇总:")
        print(f"  突变分子: {mutation_success:,}/{total_mutations:,} ({mutation_success/total_mutations*100:.1f}%)")
        print(f"  组合分子: {combination_success:,}/{num_combinations:,} ({combination_success/num_combinations*100:.1f}%)")
        print(f"  总计:     {total_success:,}/{total_attempted:,} ({total_success/total_attempted*100:.1f}%)")
        print(f"{'='*60}")
        
        return virtual_mols
    
    def is_molecule_valid(self, mol):
        """检查分子结构的合理性（严格C/H/O/N）"""
        try:
            # 检查1: 基础验证
            if mol is None:
                return False, "分子为None"
            
            # 检查2: 原子数量检查
            num_atoms = mol.GetNumAtoms()
            if num_atoms < 3:
                return False, f"原子数过少: {num_atoms}"
            if num_atoms > 500:
                return False, f"原子数过多: {num_atoms}"
            
            # 检查3: 分子量检查
            mol_weight = Descriptors.MolWt(mol)
            if mol_weight < 120:
                return False, f"分子量过小: {mol_weight:.1f}"
            if mol_weight > 350:
                return False, f"分子量过大: {mol_weight:.1f}"
            
            # 检查4: 价态验证
            try:
                Chem.SanitizeMol(mol)
            except Exception as e:
                return False, f"价态异常: {str(e)[:50]}"
            
            # 检查5: SMILES有效性
            try:
                smi = Chem.MolToSmiles(mol)
                if not smi or len(smi.strip()) == 0:
                    return False, "SMILES为空"
            except:
                return False, "SMILES生成失败"
            
            # 检查6: 常见错误结构 - 检查是否有断开的连接
            frags = Chem.GetMolFrags(mol, asMols=True)
            if len(frags) > 1:  # 组合分子应该是单一共价连接的分子
                return False, f"存在多个独立片段: {len(frags)}"
            
            # 检查7: 严格元素检查 - 只允许C,H,O,N
            allowed_elements = {'H', 'C', 'N', 'O'}
            for atom in mol.GetAtoms():
                symbol = atom.GetSymbol()
                if symbol not in allowed_elements:
                    return False, f"含有非C,H,O,N元素: {symbol}"
            
            # 检查8: 电荷检查
            total_charge = Chem.GetFormalCharge(mol)
            if abs(total_charge) > 2:
                return False, f"总电荷过高: {total_charge}"
            
            # 检查9: 禁止过氧化物
            if 'peroxide' in self.unstable_patterns:
                if mol.HasSubstructMatch(self.unstable_patterns['peroxide']):
                    return False, "含过氧键，不适合推进剂"
            
            return True, "通过"
            
        except Exception as e:
            return False, f"检查异常: {str(e)[:50]}"
    
    def filter_valid_molecules(self, molecules):
        """过滤掉不合理的分子，并去重"""
        valid_mols = []
        seen_smiles = set()
        invalid_reasons = {}
        duplicate_count = 0
        
        print("\n开始分子合理性评估与过滤...")
        with tqdm(total=len(molecules), desc="合理性检查中", unit="个") as pbar:
            for mol in molecules:
                is_valid, reason = self.is_molecule_valid(mol)
                if is_valid:
                    try:
                        smi = Chem.MolToSmiles(mol)
                        if smi not in seen_smiles:
                            seen_smiles.add(smi)
                            valid_mols.append(mol)
                        else:
                            duplicate_count += 1
                    except:
                        invalid_reasons['SMILES生成失败'] = invalid_reasons.get('SMILES生成失败', 0) + 1
                else:
                    invalid_reasons[reason] = invalid_reasons.get(reason, 0) + 1
                pbar.update(1)
        
        print(f"\n{'='*60}")
        print(f"🔍 分子合理性过滤统计:")
        print(f"  输入总数: {len(molecules):,}")
        print(f"  有效分子: {len(valid_mols):,} ({len(valid_mols)/len(molecules)*100:.1f}%)")
        print(f"  过滤分子: {len(molecules)-len(valid_mols)-duplicate_count:,}")
        print(f"  重复分子: {duplicate_count:,}")
        
        if invalid_reasons:
            print(f"\n  主要过滤原因:")
            sorted_reasons = sorted(invalid_reasons.items(), key=lambda x: x[1], reverse=True)
            for reason, count in sorted_reasons[:5]:
                print(f"    - {reason}: {count:,}")
        print(f"{'='*60}")
        
        return valid_mols
    
    def filter_only_cho_n_molecules(self, molecules):
        """只保留含C,H,O,N的分子，过滤其他元素"""
        valid_mols = []
        invalid_count = 0
        invalid_elements = set()
        
        allowed_elements = {'C', 'H', 'O', 'N'}
        
        print("\n只保留含C,H,O,N的分子...")
        with tqdm(total=len(molecules), desc="元素检查中", unit="个") as pbar:
            for mol in molecules:
                is_valid = True
                try:
                    for atom in mol.GetAtoms():
                        symbol = atom.GetSymbol()
                        if symbol not in allowed_elements:
                            is_valid = False
                            invalid_elements.add(symbol)
                            break
                except:
                    is_valid = False
                
                if is_valid:
                    valid_mols.append(mol)
                else:
                    invalid_count += 1
                pbar.update(1)
        
        print(f"\n{'='*60}")
        print(f"🔬 C,H,O,N元素过滤统计:")
        print(f"  输入总数: {len(molecules):,}")
        print(f"  保留分子: {len(valid_mols):,}")
        print(f"  过滤分子: {invalid_count:,}")
        if invalid_elements:
            print(f"  发现的其他元素: {', '.join(sorted(invalid_elements))}")
        print(f"{'='*60}")
        
        return valid_mols
    
    def screen_and_classify(self, molecules, filter_molecules=True):
        """
        对分子进行推进剂适用性评估与分类（新增密度列）
        
        Args:
            molecules: 待评估的分子列表
            filter_molecules: 是否进行合理性过滤（对原始分子设为False）
        """
        # 检查是否需要过滤
        if filter_molecules:
            valid_mols = self.filter_valid_molecules(molecules)
        else:
            valid_mols = molecules
            print(f"\n跳过合理性过滤，直接评估 {len(valid_mols)} 个分子")
        
        results = []
        
        print("\n开始推进剂适用性评估与分类...")
        with tqdm(total=len(valid_mols), desc="评估中", unit="个") as pbar:
            for mol in valid_mols:
                try:
                    smi = Chem.MolToSmiles(mol)
                    score, factors = self.calculate_propellant_score(mol)
                    suitability = self.classify_propellant_suitability(score)
                    
                    # 计算总原子数（包括隐式氢原子）
                    total_atoms = mol.GetNumAtoms() + sum(atom.GetNumImplicitHs() for atom in mol.GetAtoms())
                    # 获取氧平衡值
                    oxygen_balance = factors.get('oxygen_balance')
                    # 获取估算密度值
                    density_est = factors.get('density_est')
                    
                    results.append({
                        'smiles': smi,
                        'atom_count': total_atoms,
                        'oxygen_balance': oxygen_balance,
                        'density_est': density_est,  # 新增：估算密度列
                        'propellant_score': score,
                        'propellant_suitability': suitability,
                        'factors': str(factors),
                        'mol_weight': Descriptors.MolWt(mol)
                    })
                except Exception as e:
                    print(f"⚠️ 分子评估失败: {str(e)[:50]}")
                pbar.update(1)
        
        print(f"\n✓ 完成 {len(results)} 个分子的评估")
        return pd.DataFrame(results)
    
    def save_results(self, df, output_prefix='results'):
        # 确保没有重复的SMILES（最终保障）
        if 'smiles' in df.columns:
            df = df.drop_duplicates(subset=['smiles'], keep='first')
        
        # 按适用性等级分类保存
        df_excellent = df[df['propellant_suitability'] == '优秀']
        df_good = df[df['propellant_suitability'] == '良好']
        df_average = df[df['propellant_suitability'] == '一般']
        df_unsuitable = df[df['propellant_suitability'] == '不适用']
        
        df_excellent.to_csv(f'{output_prefix}_excellent.csv', index=False, encoding='utf-8-sig')
        df_good.to_csv(f'{output_prefix}_good.csv', index=False, encoding='utf-8-sig')
        df_average.to_csv(f'{output_prefix}_average.csv', index=False, encoding='utf-8-sig')
        df_unsuitable.to_csv(f'{output_prefix}_unsuitable.csv', index=False, encoding='utf-8-sig')
        df.to_csv(f'{output_prefix}_all.csv', index=False, encoding='utf-8-sig')
        
        print(f"\n结果保存完成：")
        print(f"优秀: {len(df_excellent)} 个分子")
        print(f"良好: {len(df_good)} 个分子")
        print(f"一般: {len(df_average)} 个分子")
        print(f"不适用: {len(df_unsuitable)} 个分子")
        print(f"总计: {len(df)} 个分子")
        print(f"文件: {output_prefix}_all.csv, {output_prefix}_excellent.csv 等")

def main():
    parser = argparse.ArgumentParser(description='固体推进剂专用含能分子虚拟生成与筛选系统')
    parser.add_argument('--input', type=str, default='密度.csv', 
                        help='输入CSV文件路径 (默认: 密度.csv)')
    parser.add_argument('--mutations', type=int, default=2, 
                        help='每个分子的突变次数 (默认: 2)')
    parser.add_argument('--combinations', type=int, default=200, 
                        help='组合生成的分子数量 (默认: 200)')
    parser.add_argument('--output', type=str, default='propellant_candidates', 
                        help='输出文件前缀 (默认: propellant_candidates)')
    parser.add_argument('--no-generation', action='store_true',
                        help='仅筛选现有分子，不生成新分子')
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("固体推进剂专用含能分子虚拟生成与筛选系统")
    print("=" * 60)
    print(f"\n配置参数：")
    print(f"  输入文件: {args.input}")
    if not args.no_generation:
        print(f"  每个分子突变次数: {args.mutations}")
        print(f"  组合分子数量: {args.combinations}")
    print(f"  输出前缀: {args.output}")
    print(f"  仅筛选模式: {args.no_generation}")
    
    generator = EnergeticMoleculeGenerator(args.input)
    
    print("\n分析原始分子库...")
    # 原始分子直接分析
    original_results = generator.screen_and_classify(generator.molecules, filter_molecules=False)
    generator.save_results(original_results, 'original_propellant')
    
    # 只使用含C,H,O,N的分子用于生成虚拟分子
    cho_n_molecules = generator.filter_only_cho_n_molecules(generator.molecules)
    
    # 更新生成器使用的分子库
    generator.molecules = cho_n_molecules
    # 重新进行官能团分组和位点预计算
    generator._group_molecules_by_functional_groups()
    
    all_mols = []
    
    if not args.no_generation:
        print("\n" + "=" * 60)
        print("开始虚拟分子生成...")
        print("=" * 60)
        virtual_mols = generator.generate_virtual_library(
            num_mutations_per_mol=args.mutations,
            num_combinations=args.combinations
        )
        
        print("\n" + "=" * 60)
        print("对虚拟分子进行合理性过滤...")
        print("=" * 60)
        valid_virtual_mols = generator.filter_valid_molecules(virtual_mols)
        
        all_mols = valid_virtual_mols
        print(f"\n总共 {len(all_mols)} 个虚拟分子待筛选")
    else:
        # 仅筛选模式下使用原始分子
        all_mols = generator.molecules
    
    print("\n" + "=" * 60)
    print("开始推进剂适用性评估与分类...")
    print("=" * 60)
    all_results = generator.screen_and_classify(all_mols, filter_molecules=False)
    
    generator.save_results(all_results, args.output)
    
    print("\n" + "=" * 60)
    print("分析完成！")
    print("=" * 60)
    
    print("\n适用性统计：")
    print(all_results['propellant_suitability'].value_counts())
    
    if not args.no_generation and len(all_results[all_results['propellant_suitability'] == '优秀']) > 0:
        print("\n优秀候选分子示例：")
        excellent = all_results[all_results['propellant_suitability'] == '优秀'].head(5)
        for idx, row in excellent.iterrows():
            print(f"SMILES: {row['smiles'][:50]}...")
            print(f"推进剂评分: {row['propellant_score']}, 氧平衡: {row['oxygen_balance']}, 密度: {row['density_est']} g/cm³")
            print(f"氮含量: {eval(row['factors'])['nitrogen_percent']}%, 分子量: {row['mol_weight']:.1f}")
            print()

if __name__ == "__main__":
    main()