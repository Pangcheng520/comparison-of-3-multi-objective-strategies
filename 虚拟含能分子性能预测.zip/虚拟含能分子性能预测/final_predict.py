# -*- coding: utf-8 -*-
"""
最终版：虚拟含能分子性能预测
使用 joblib 加载模型
"""
import pandas as pd
import numpy as np
import joblib
import warnings
warnings.filterwarnings('ignore')

from rdkit import Chem
from rdkit.Chem import Descriptors
from rdkit.ML.Descriptors import MoleculeDescriptors


def calculate_descriptors(input_file="虚拟分子.csv", smiles_column="smiles"):
    """
    计算所有RDKit描述符
    """
    try:
        df = pd.read_csv(input_file)
        print(f"✓ 成功读取 {len(df)} 条记录")
    except Exception as e:
        print(f"✗ 读取文件失败: {e}")
        return None
    
    # 获取所有描述符
    descriptor_names = [name for name, _ in Descriptors.descList]
    calculator = MoleculeDescriptors.MolecularDescriptorCalculator(descriptor_names)
    
    results = []
    for idx, row in df.iterrows():
        if idx % 50 == 0:
            print(f"  正在处理 {idx+1}/{len(df)}...")
        
        smiles = row[smiles_column]
        try:
            mol = Chem.MolFromSmiles(smiles)
            if mol is not None:
                desc_values = calculator.CalcDescriptors(mol)
                results.append(desc_values)
            else:
                results.append([np.nan] * len(descriptor_names))
        except:
            results.append([np.nan] * len(descriptor_names))
    
    desc_df = pd.DataFrame(results, columns=descriptor_names)
    final_df = pd.concat([df, desc_df], axis=1)
    print(f"✓ 描述符计算完成")
    return final_df


def load_models():
    """
    加载所有模型和标准化器
    """
    print("\n正在加载模型...")
    
    models = {}
    
    # 密度模型
    try:
        models['density_model'] = joblib.load("密度预测SVR模型.pkl")
        models['density_scaler'] = joblib.load("密度预测SVR模型标准化器.pkl")
        print("  ✓ 密度模型加载成功")
    except Exception as e:
        print(f"  ✗ 密度模型加载失败: {e}")
    
    # 生成焓模型
    try:
        models['enthalpy_model'] = joblib.load("生成焓预测LASSO模型.pkl")
        models['enthalpy_scaler'] = joblib.load("生成焓预测LASSO模型标准化器.pkl")
        print("  ✓ 生成焓模型加载成功")
    except Exception as e:
        print(f"  ✗ 生成焓模型加载失败: {e}")
    
    # 撞击感度模型
    try:
        impact_obj = joblib.load("撞击感度预测LASSO模型.pkl")
        if isinstance(impact_obj, dict):
            # 完美！字典结构是 {'model': ..., 'scaler': ..., 'feature_names': ...}
            models['impact_model'] = impact_obj['model']
            models['impact_scaler'] = impact_obj['scaler']
            models['impact_feature_names'] = impact_obj['feature_names']
        else:
            models['impact_model'] = impact_obj
            
        print("  ✓ 撞击感度模型加载成功")
    except Exception as e:
        print(f"  ✗ 撞击感度模型加载失败: {e}")
    
    return models


def predict_properties(desc_df, models):
    """
    使用模型预测所有性能
    """
    smiles_df = desc_df[['smiles']].copy()
    
    # ========== 预测密度 ==========
    if 'density_model' in models and 'density_scaler' in models:
        try:
            scaler = models['density_scaler']
            feature_names = scaler.feature_names_in_
            
            # 提取需要的特征
            X = desc_df[feature_names].copy()
            X = X.fillna(0)
            
            # 标准化
            X_scaled = scaler.transform(X)
            
            # 预测
            density_pred = models['density_model'].predict(X_scaled)
            smiles_df['预测密度'] = density_pred
            print("  ✓ 密度预测完成")
        except Exception as e:
            print(f"  ✗ 密度预测失败: {e}")
            smiles_df['预测密度'] = np.nan
    else:
        smiles_df['预测密度'] = np.nan
    
    # ========== 预测生成焓 ==========
    if 'enthalpy_model' in models and 'enthalpy_scaler' in models:
        try:
            scaler = models['enthalpy_scaler']
            feature_names = scaler.feature_names_in_
            
            X = desc_df[feature_names].copy()
            X = X.fillna(0)
            
            X_scaled = scaler.transform(X)
            enthalpy_pred = models['enthalpy_model'].predict(X_scaled)
            smiles_df['预测生成焓'] = enthalpy_pred
            print("  ✓ 生成焓预测完成")
        except Exception as e:
            print(f"  ✗ 生成焓预测失败: {e}")
            smiles_df['预测生成焓'] = np.nan
    else:
        smiles_df['预测生成焓'] = np.nan
    
    # ========== 预测撞击感度 ==========
    if 'impact_model' in models:
        try:
            model = models['impact_model']
            
            # 使用字典中保存的特征名
            feature_names = models['impact_feature_names']
            
            X = desc_df[feature_names].copy()
            X = X.fillna(0)
            
            # 标准化
            X_scaled = models['impact_scaler'].transform(X)
            impact_pred = model.predict(X_scaled)
            
            smiles_df['预测撞击感度'] = impact_pred
            print("  ✓ 撞击感度预测完成")
        except Exception as e:
            print(f"  ✗ 撞击感度预测失败: {e}")
            import traceback
            traceback.print_exc()
            smiles_df['预测撞击感度'] = np.nan
    else:
        smiles_df['预测撞击感度'] = np.nan
    
    return smiles_df


def main():
    print("="*70)
    print("  虚拟含能分子性能预测 - 最终版")
    print("="*70)
    
    # 1. 计算描述符
    print("\n[1/3] 计算分子描述符...")
    desc_df = calculate_descriptors()
    
    if desc_df is None:
        print("\n✗ 描述符计算失败，程序终止")
        return
    
    # 2. 加载模型
    print("\n[2/3] 加载模型...")
    models = load_models()
    
    # 3. 预测
    print("\n[3/3] 进行性能预测...")
    predictions_df = predict_properties(desc_df, models)
    
    # 4. 保存结果
    output_file = "虚拟分子预测结果.csv"
    predictions_df.to_csv(output_file, index=False, encoding='utf-8-sig')
    
    print(f"\n{'='*70}")
    print(f"✓ 预测完成！结果已保存至: {output_file}")
    print(f"\n预测结果预览:")
    print(predictions_df.head(10))
    print(f"{'='*70}")


if __name__ == "__main__":
    main()
