# -*- coding: utf-8 -*-
"""
深度分析所有文件
"""
import pickle
import os
import numpy as np

def analyze_file(file_path):
    print(f"\n{'='*70}")
    print(f"文件: {file_path}")
    print(f"{'='*70}")
    
    if not os.path.exists(file_path):
        print("文件不存在")
        return
    
    size = os.path.getsize(file_path)
    print(f"大小: {size} bytes")
    
    # 先尝试作为普通对象加载
    try:
        with open(file_path, 'rb') as f:
            obj = pickle.load(f)
        
        print(f"\n✓ 成功加载!")
        print(f"  类型: {type(obj)}")
        
        if isinstance(obj, np.ndarray):
            print(f"  形状: {obj.shape}")
            print(f"  dtype: {obj.dtype}")
            
            if obj.dtype == object or obj.dtype.kind in ['U', 'S']:
                print(f"\n  内容（特征名称）:")
                for i, name in enumerate(obj):
                    print(f"    [{i}] {name}")
                return obj
        
        # 如果不是数组，打印其他信息
        if hasattr(obj, '__dict__'):
            print(f"\n  属性: {list(obj.__dict__.keys())}")
        
        return obj
        
    except Exception as e:
        print(f"\n✗ 直接加载失败: {e}")
    
    # 尝试逐字节分析
    print(f"\n尝试低级分析...")
    with open(file_path, 'rb') as f:
        data = f.read()
    
    # 搜索可读字符串
    print(f"\n搜索文件中的可读字符串:")
    strings = []
    current_str = []
    for byte in data:
        if 32 <= byte <= 126:
            current_str.append(chr(byte))
        else:
            if len(current_str) >= 4:
                strings.append(''.join(current_str))
            current_str = []
    
    if strings:
        unique_strings = list(set(strings))
        print(f"找到 {len(unique_strings)} 个可能的字符串:")
        for s in sorted(unique_strings)[:30]:
            print(f"  - {s}")
    
    return None

files = [
    "密度预测SVR模型.pkl",
    "密度预测SVR模型标准化器.pkl", 
    "生成焓预测LASSO模型.pkl",
    "生成焓预测LASSO模型标准化器.pkl",
    "撞击感度预测LASSO模型.pkl"
]

print("="*70)
print("深度模型文件分析")
print("="*70)

results = {}
for f in files:
    results[f] = analyze_file(f)

print("\n" + "="*70)
print("分析完成!")
print("="*70)

# 总结特征名称
print("\n\n特征名称总结:")
print("-"*70)
for f in files:
    if '标准化器' in f and f in results and isinstance(results[f], np.ndarray):
        print(f"\n{f}:")
        print(f"  包含 {len(results[f])} 个特征")
