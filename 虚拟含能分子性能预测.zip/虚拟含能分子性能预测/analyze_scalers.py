# -*- coding: utf-8 -*-
"""
分析能加载的标准化器文件
"""
import pickle
import numpy as np

files = [
    "密度预测SVR模型标准化器.pkl",
    "生成焓预测LASSO模型标准化器.pkl"
]

print("="*60)
print("分析标准化器文件")
print("="*60)

for f in files:
    print(f"\n文件: {f}")
    print("-"*60)
    
    with open(f, 'rb') as fobj:
        data = pickle.load(fobj)
    
    print(f"类型: {type(data)}")
    
    if isinstance(data, np.ndarray):
        print(f"形状: {data.shape}")
        print(f"dtype: {data.dtype}")
        print(f"前10个值: {data[:10]}")
        print(f"最小值: {data.min()}, 最大值: {data.max()}")
        print(f"平均值: {data.mean()}")
        
        if len(data) == 2:
            print("\n看起来像是(mean, std)格式！")
            print(f"mean = {data[0]}")
            print(f"std = {data[1]}")

print("\n" + "="*60)
