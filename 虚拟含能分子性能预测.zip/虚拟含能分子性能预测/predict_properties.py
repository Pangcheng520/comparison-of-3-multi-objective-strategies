# -*- coding: utf-8 -*-
"""
虚拟含能分子性能预测流程
功能：计算描述符并预测密度、生成焓和撞击感度
优化：修复模型加载和描述符计算问题
"""

import pandas as pd
import numpy as np
import pickle
import warnings
warnings.filterwarnings('ignore')

from rdkit import Chem
from rdkit.Chem import Descriptors
from rdkit.ML.Descriptors import MoleculeDescriptors
import os
import sys

def calculate_rdkit_descriptors(input_file="虚拟分子.csv", smiles_column="smiles"):
    """
    计算RDKit描述符（优化版，排除计算慢的描述符）
    """
    try:
        df = pd.read_csv(input_file)
        print(f"成功读取 {len(df)} 条记录")
    except FileNotFoundError:
        print(f"错误: 文件 '{input_file}' 不存在")
        return None
    except Exception as e:
        print(f"错误: 读取文件时发生错误: {str(e)}")
        return None
    
    # 排除计算非常慢的描述符，如Ipc相关的描述符
    exclude_descriptors = ['Ipc', 'AvgIpc']
    descriptors_list = [(name, func) for name, func in Descriptors.descList 
                       if name not in exclude_descriptors]
    descriptor_names = [name for name, _ in descriptors_list]
    print(f"将计算 {len(descriptor_names)} 个RDKit描述符（已排除慢速描述符）")
    
    calculator = MoleculeDescriptors.MolecularDescriptorCalculator(descriptor_names)
    results = []
    invalid_indices = []
    
    for idx, row in df.iterrows():
        if idx % 50 == 0:
            print(f"正在处理第 {idx+1}/{len(df)} 条记录...")
        
        smiles = row[smiles_column]
        try:
            mol = Chem.MolFromSmiles(smiles)
            if mol is not None:
                descriptor_values = calculator.CalcDescriptors(mol)
                results.append(descriptor_values)
            else:
                results.append([np.nan] * len(descriptor_names))
                invalid_indices.append(idx)
        except Exception as e:
            results.append([np.nan] * len(descriptor_names))
            invalid_indices.append(idx)
    
    if invalid_indices:
        print(f"警告: {len(invalid_indices)} 条记录存在问题")
    
    descriptors_df = pd.DataFrame(results, columns=descriptor_names)
    final_df = pd.concat([df, descriptors_df], axis=1)
    return final_df

def safe_load_pickle(file_path):
    """
    安全加载pickle文件
    """
    try:
        with open(file_path, 'rb') as f:
            obj = pickle.load(f)
        return obj
    except Exception as e:
        print(f"  加载 {file_path} 时出错: {str(e)}")
        print(f"  尝试备选加载方式...")
        try:
            # 尝试使用不同的编码
            with open(file_path, 'rb') as f:
                obj = pickle.load(f, encoding='latin1')
            return obj
        except:
            print(f"  备选加载方式也失败")
            return None

def load_model_and_scaler(model_path, scaler_path):
    """
    加载模型和标准化器
    """
    model = safe_load_pickle(model_path)
    scaler = safe_load_pickle(scaler_path)
    return model, scaler

def get_model_features(model):
    """
    获取模型期望的特征数量
    """
    try:
        if hasattr(model, 'n_features_in_'):
            return model.n_features_in_
        elif hasattr(model, 'coef_'):
            return len(model.coef_)
        elif hasattr(model, 'support_vectors_'):
            return model.support_vectors_.shape[1]
        return None
    except:
        return None

def predict_properties(descriptors_df):
    """
    使用模型预测所有性能（鲁棒版本）
    """
    smiles_df = descriptors_df[['smiles']].copy()
    
    descriptors_only = descriptors_df.drop(['smiles'], axis=1)
    descriptors_only = descriptors_only.fillna(0)
    
    # 预测密度
    print("\n=== 预测密度 ===")
    density_model, density_scaler = load_model_and_scaler(
        "密度预测SVR模型.pkl", 
        "密度预测SVR模型标准化器.pkl"
    )
    
    if density_model is not None and density_scaler is not None:
        try:
            X_scaled_density = density_scaler.transform(descriptors_only)
            density_predictions = density_model.predict(X_scaled_density)
            smiles_df['预测密度'] = density_predictions
            print("  ✓ 密度预测完成")
        except Exception as e:
            print(f"  ✗ 密度预测失败: {str(e)}")
            smiles_df['预测密度'] = np.nan
    else:
        print("  ✗ 密度模型或标准化器加载失败")
        smiles_df['预测密度'] = np.nan
    
    # 预测生成焓
    print("\n=== 预测生成焓 ===")
    enthalpy_model, enthalpy_scaler = load_model_and_scaler(
        "生成焓预测LASSO模型.pkl", 
        "生成焓预测LASSO模型标准化器.pkl"
    )
    
    if enthalpy_model is not None and enthalpy_scaler is not None:
        try:
            X_scaled_enthalpy = enthalpy_scaler.transform(descriptors_only)
            enthalpy_predictions = enthalpy_model.predict(X_scaled_enthalpy)
            smiles_df['预测生成焓'] = enthalpy_predictions
            print("  ✓ 生成焓预测完成")
        except Exception as e:
            print(f"  ✗ 生成焓预测失败: {str(e)}")
            smiles_df['预测生成焓'] = np.nan
    else:
        print("  ✗ 生成焓模型或标准化器加载失败")
        smiles_df['预测生成焓'] = np.nan
    
    # 预测撞击感度
    print("\n=== 预测撞击感度 ===")
    impact_model = safe_load_pickle("撞击感度预测LASSO模型.pkl")
    
    if impact_model is not None:
        try:
            impact_scaler = safe_load_pickle("撞击感度预测LASSO模型标准化器.pkl")
            if impact_scaler is not None:
                X_scaled_impact = impact_scaler.transform(descriptors_only)
            else:
                X_scaled_impact = descriptors_only
            impact_predictions = impact_model.predict(X_scaled_impact)
            smiles_df['预测撞击感度'] = impact_predictions
            print("  ✓ 撞击感度预测完成")
        except Exception as e:
            print(f"  ✗ 撞击感度预测失败: {str(e)}")
            smiles_df['预测撞击感度'] = np.nan
    else:
        print("  ✗ 撞击感度模型加载失败")
        smiles_df['预测撞击感度'] = np.nan
    
    return smiles_df

def main():
    print("="*60)
    print("虚拟含能分子性能预测")
    print("="*60)
    
    print("\n[1/3] 计算分子描述符...")
    descriptors_df = calculate_rdkit_descriptors()
    
    if descriptors_df is None:
        print("描述符计算失败，程序终止")
        return
    
    print("\n[2/3] 使用模型进行预测...")
    predictions_df = predict_properties(descriptors_df)
    
    print("\n[3/3] 保存预测结果...")
    output_file = "虚拟分子预测结果.csv"
    predictions_df.to_csv(output_file, index=False, encoding='utf-8-sig')
    
    print(f"\n✓ 预测完成！结果已保存到: {output_file}")
    print("\n" + "="*60)
    print("预测结果预览:")
    print(predictions_df.head())
    print("="*60)

if __name__ == "__main__":
    print("虚拟含能分子性能预测程序")
    main()
