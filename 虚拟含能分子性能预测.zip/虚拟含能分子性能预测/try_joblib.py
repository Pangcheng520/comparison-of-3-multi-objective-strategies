# -*- coding: utf-8 -*-
"""
专门尝试用 joblib 加载
"""
import os
import numpy as np

def try_joblib_load(file_path):
    print(f"\n{'='*70}")
    print(f"文件: {file_path}")
    print(f"{'='*70}")
    
    if not os.path.exists(file_path):
        print("文件不存在")
        return None
    
    size = os.path.getsize(file_path)
    print(f"大小: {size} bytes")
    
    try:
        import joblib
        print(f"\n尝试用 joblib.load() 加载...")
        obj = joblib.load(file_path)
        
        print(f"\n✓ Joblib加载成功!")
        print(f"  类型: {type(obj)}")
        print_model_info(obj)
        return obj
        
    except Exception as e:
        print(f"\n✗ Joblib加载失败: {e}")
        
        # 尝试不同的参数
        try:
            print(f"\n尝试 joblib.load(..., mmap_mode=None)...")
            obj = joblib.load(file_path, mmap_mode=None)
            print(f"\n✓ 成功!")
            print_model_info(obj)
            return obj
        except Exception as e2:
            print(f"✗ 也失败: {e2}")
    
    return None

def print_model_info(obj):
    """打印模型详细信息"""
    print(f"\n对象详细信息:")
    
    if hasattr(obj, '__dict__'):
        print(f"  属性列表: {list(obj.__dict__.keys())}")
    
    # scikit-learn 模型特有的属性
    if hasattr(obj, 'n_features_in_'):
        print(f"  n_features_in_: {obj.n_features_in_}")
    
    if hasattr(obj, 'coef_'):
        coef = np.array(obj.coef_)
        print(f"  coef_: 形状={coef.shape}, dtype={coef.dtype}")
        print(f"  coef_ 非零元素数: {np.count_nonzero(coef)}")
        if coef.size < 20:
            print(f"  coef_ 内容: {coef}")
    
    if hasattr(obj, 'intercept_'):
        print(f"  intercept_: {obj.intercept_}")
    
    if hasattr(obj, 'support_vectors_'):
        print(f"  support_vectors_: 形状={obj.support_vectors_.shape}")
    
    if hasattr(obj, '_sklearn_version'):
        print(f"  _sklearn_version: {obj._sklearn_version}")
    
    if isinstance(obj, np.ndarray):
        print(f"  数组形状: {obj.shape}")
        print(f"  数组 dtype: {obj.dtype}")
        if obj.dtype == object or obj.dtype.kind in ['U', 'S']:
            print(f"  内容（前10个）: {obj[:10]}")

files = [
    "密度预测SVR模型.pkl",
    "密度预测SVR模型标准化器.pkl",
    "生成焓预测LASSO模型.pkl",
    "生成焓预测LASSO模型标准化器.pkl",
    "撞击感度预测LASSO模型.pkl"
]

print("="*70)
print("专门用 Joblib 加载模型")
print("="*70)

results = {}
for f in files:
    results[f] = try_joblib_load(f)

print("\n" + "="*70)
print("加载完成!")
print("="*70)
