# -*- coding: utf-8 -*-
"""
检查撞击感度模型的dict内容
"""
import joblib

print("="*70)
print("检查撞击感度模型")
print("="*70)

# 加载撞击感度模型
impact_file = "撞击感度预测LASSO模型.pkl"
obj = joblib.load(impact_file)

print(f"\n类型: {type(obj)}")

if isinstance(obj, dict):
    print(f"\n字典键: {list(obj.keys())}")
    
    for key, value in obj.items():
        print(f"\n[{key}]")
        print(f"  类型: {type(value)}")
        
        if hasattr(value, 'n_features_in_'):
            print(f"  n_features_in_: {value.n_features_in_}")
        
        if hasattr(value, 'coef_'):
            import numpy as np
            print(f"  coef_ 形状: {np.array(value.coef_).shape}")
        
        if hasattr(value, '__dict__'):
            print(f"  属性: {list(value.__dict__.keys())}")

print("\n" + "="*70)
