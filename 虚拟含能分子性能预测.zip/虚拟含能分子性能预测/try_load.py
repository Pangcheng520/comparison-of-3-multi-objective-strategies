# -*- coding: utf-8 -*-
"""
尝试多种方法加载模型文件
"""
import os
import pickle
import numpy as np

def try_pickle_load(file_path, encoding=None):
    """尝试用pickle加载"""
    try:
        with open(file_path, 'rb') as f:
            if encoding:
                obj = pickle.load(f, encoding=encoding)
            else:
                obj = pickle.load(f)
        return obj, None
    except Exception as e:
        return None, str(e)

def try_unpickle_module(file_path):
    """尝试直接读取并分析"""
    try:
        import pickletools
        with open(file_path, 'rb') as f:
            data = f.read()
        
        # 尝试分析前几个操作码
        print("  Pickle操作码分析:")
        ops = list(pickletools.genops(data))
        for i, op in enumerate(ops[:10]):
            print(f"    操作{i}: {op}")
        
        return None, "分析完成"
    except Exception as e:
        return None, str(e)

def check_file(file_path):
    print(f"\n{'='*60}")
    print(f"检查文件: {file_path}")
    print(f"{'='*60}")
    
    if not os.path.exists(file_path):
        print("  文件不存在")
        return
    
    size = os.path.getsize(file_path)
    print(f"  文件大小: {size} bytes")
    
    # 方法1: 普通pickle
    print("\n[方法1] 普通pickle加载...")
    obj, err = try_pickle_load(file_path)
    if obj is not None:
        print(f"  ✓ 成功! 类型: {type(obj)}")
        print_obj_info(obj)
        return obj
    else:
        print(f"  ✗ 失败: {err}")
    
    # 方法2: latin1编码
    print("\n[方法2] latin1编码加载...")
    obj, err = try_pickle_load(file_path, encoding='latin1')
    if obj is not None:
        print(f"  ✓ 成功! 类型: {type(obj)}")
        print_obj_info(obj)
        return obj
    else:
        print(f"  ✗ 失败: {err}")
    
    # 方法3: bytes编码
    print("\n[方法3] bytes编码加载...")
    obj, err = try_pickle_load(file_path, encoding='bytes')
    if obj is not None:
        print(f"  ✓ 成功! 类型: {type(obj)}")
        print_obj_info(obj)
        return obj
    else:
        print(f"  ✗ 失败: {err}")
    
    # 方法4: 分析pickle结构
    print("\n[方法4] 分析pickle结构...")
    try_unpickle_module(file_path)
    
    # 尝试用joblib
    print("\n[方法5] 尝试joblib加载...")
    try:
        import joblib
        obj = joblib.load(file_path)
        print(f"  ✓ Joblib成功! 类型: {type(obj)}")
        print_obj_info(obj)
        return obj
    except Exception as e:
        print(f"  ✗ Joblib失败: {str(e)}")
    
    return None

def print_obj_info(obj):
    """打印对象信息"""
    print(f"  对象信息:")
    print(f"    类型: {type(obj)}")
    
    if hasattr(obj, '__dict__'):
        print(f"    属性: {list(obj.__dict__.keys())}")
    
    if hasattr(obj, 'n_features_in_'):
        print(f"    n_features_in_: {obj.n_features_in_}")
    
    if hasattr(obj, 'coef_'):
        print(f"    coef_ shape: {np.array(obj.coef_).shape if hasattr(obj.coef_, 'shape') else type(obj.coef_)}")
    
    if hasattr(obj, 'support_vectors_'):
        print(f"    support_vectors_ shape: {obj.support_vectors_.shape}")
    
    if isinstance(obj, np.ndarray):
        print(f"    数组形状: {obj.shape}")
        print(f"    数组 dtype: {obj.dtype}")
        if obj.size < 20:
            print(f"    数组内容: {obj}")

files = [
    "密度预测SVR模型.pkl",
    "密度预测SVR模型标准化器.pkl",
    "生成焓预测LASSO模型.pkl",
    "生成焓预测LASSO模型标准化器.pkl",
    "撞击感度预测LASSO模型.pkl"
]

print("="*60)
print("模型文件多方法加载测试")
print("="*60)

for f in files:
    check_file(f)

print("\n" + "="*60)
