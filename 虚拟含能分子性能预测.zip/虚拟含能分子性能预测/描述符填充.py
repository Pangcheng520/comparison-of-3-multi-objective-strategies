# -*- coding: utf-8 -*-
"""
Created on Tue Jun 10 15:39:44 2025

@author: Administrator
"""

import pandas as pd
import numpy as np
from rdkit import Chem
from rdkit.Chem import Descriptors
from rdkit.ML.Descriptors import MoleculeDescriptors

def calculate_rdkit_descriptors(input_file="data.csv", output_file="data_with_descriptors.csv", smiles_column="canonical_smiles"):
    """
    计算CSV文件中SMILES列的所有RDKit描述符
    
    参数:
    input_file (str): 输入CSV文件路径，默认为"data.csv"
    output_file (str): 输出CSV文件路径，默认为"data_with_descriptors.csv"
    smiles_column (str): SMILES列的列名，默认为"canonical_smiles"
    """
    # 读取CSV文件
    try:
        df = pd.read_csv(input_file)
        print(f"成功读取 {len(df)} 条记录")
    except FileNotFoundError:
        print(f"错误: 文件 '{input_file}' 不存在")
        return
    except Exception as e:
        print(f"错误: 读取文件时发生错误: {str(e)}")
        return
    
    # 获取所有RDKit描述符的名称和函数
    descriptors_list = [(name, func) for name, func in Descriptors.descList]
    descriptor_names = [name for name, _ in descriptors_list]
    print(f"将计算 {len(descriptor_names)} 个RDKit描述符")
    
    # 创建描述符计算器
    calculator = MoleculeDescriptors.MolecularDescriptorCalculator(descriptor_names)
    
    # 初始化结果列表
    results = []
    invalid_indices = []
    
    # 遍历每一行，计算描述符
    for idx, row in df.iterrows():
        smiles = row[smiles_column]
        
        try:
            # 从SMILES创建分子对象
            mol = Chem.MolFromSmiles(smiles)
            
            if mol is not None:
                # 计算描述符
                descriptor_values = calculator.CalcDescriptors(mol)
                results.append(descriptor_values)
            else:
                # 处理无效SMILES
                results.append([np.nan] * len(descriptor_names))
                invalid_indices.append(idx)
                print(f"警告: 第 {idx+2} 行的SMILES无效: {smiles}")
                
        except Exception as e:
            # 处理计算错误
            results.append([np.nan] * len(descriptor_names))
            invalid_indices.append(idx)
            print(f"错误: 计算第 {idx+2} 行描述符时出错: {str(e)}")
    
    # 打印处理摘要
    if invalid_indices:
        print(f"处理完成，{len(invalid_indices)} 条记录存在问题")
    else:
        print("所有记录均成功处理")
    
    # 将结果转换为DataFrame
    descriptors_df = pd.DataFrame(results, columns=descriptor_names)
    
    # 合并原始数据和描述符数据
    final_df = pd.concat([df, descriptors_df], axis=1)
    
    # 保存结果
    try:
        final_df.to_csv(output_file, index=False)
        print(f"描述符计算完成，结果已保存至 {output_file}")
    except Exception as e:
        print(f"错误: 保存文件时发生错误: {str(e)}")

if __name__ == "__main__":
    calculate_rdkit_descriptors()    