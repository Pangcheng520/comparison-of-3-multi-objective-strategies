# -*- coding: utf-8 -*-
"""
检查模型文件
"""
import pickle
import os

def check_file(file_path):
    print(f"\n检查文件: {file_path}")
    
    if not os.path.exists(file_path):
        print(f"  文件不存在")
        return False
    
    size = os.path.getsize(file_path)
    print(f"  文件大小: {size} bytes")
    
    try:
        with open(file_path, 'rb') as f:
            first_bytes = f.read(20)
            print(f"  前20字节: {first_bytes.hex()}")
            
            f.seek(0)
            try:
                obj = pickle.load(f)
                print(f"  ✓ 成功加载，类型: {type(obj)}")
                
                if hasattr(obj, 'n_features_in_'):
                    print(f"    期望特征数: {obj.n_features_in_}")
                if hasattr(obj, 'coef_'):
                    print(f"    系数形状: {obj.coef_.shape}")
                return True
            except Exception as e:
                print(f"  ✗ 加载失败: {str(e)}")
                return False
    except Exception as e:
        print(f"  ✗ 读取失败: {str(e)}")
        return False

files = [
    "密度预测SVR模型.pkl",
    "密度预测SVR模型标准化器.pkl",
    "生成焓预测LASSO模型.pkl",
    "生成焓预测LASSO模型标准化器.pkl",
    "撞击感度预测LASSO模型.pkl"
]

print("="*60)
print("模型文件检查")
print("="*60)

for f in files:
    check_file(f)

print("\n" + "="*60)
