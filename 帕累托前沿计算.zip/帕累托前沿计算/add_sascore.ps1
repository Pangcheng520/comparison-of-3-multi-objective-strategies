# 计算简化版SAscore
function Calculate-SAScore {
    param([string]$smiles)
    
    if ([string]::IsNullOrWhiteSpace($smiles)) {
        return 5.0
    }
    
    $s = $smiles.Trim()
    $score = 5.0
    
    # 1. 分子量/分子大小估算
    $length = $s.Length
    if ($length -lt 30) { $score -= 1.0 }
    elseif ($length -gt 80) { $score += 2.0 }
    
    # 2. 环系统复杂度
    $ringCount = ($s.ToCharArray() | Where-Object { $_ -eq '1' -or $_ -eq '2' -or $_ -eq '3' -or $_ -eq '4' }).Count
    if ($ringCount -gt 4) { $score += 1.5 }
    if ($ringCount -gt 6) { $score += 1.0 }
    
    # 3. 杂原子数量
    $heteroCount = 0
    $heteroAtoms = @('N', 'O', 'S', 'P', 'F', 'Cl', 'Br', 'I')
    foreach ($atom in $heteroAtoms) {
        $heteroCount += ([regex]::Matches($s, $atom)).Count
    }
    if ($heteroCount -gt 8) { $score += 1.0 }
    
    # 4. 复杂官能团
    $complexGroups = @('C#N', 'C#C', 'N=O', 'S(=O)', 'P(=O)', 'B(', 'Si')
    foreach ($group in $complexGroups) {
        if ($s.Contains($group)) { $score += 0.5 }
    }
    
    # 5. 立体中心指示
    if ($s.Contains('@')) { $score += 0.5 }
    
    # 限制范围
    $score = [Math]::Max(1.0, [Math]::Min(10.0, $score))
    
    return [Math]::Round($score, 2)
}

# 主函数
Write-Host "正在添加SAscore到帕累托前沿结果..."

# 读取帕累托前沿结果
$inputFile = "帕累托前沿结果.csv"
$outputFile = "帕累托前沿结果_含SAscore.csv"

if (-not (Test-Path $inputFile)) {
    Write-Host "错误: 找不到文件 $inputFile"
    exit 1
}

$data = Import-Csv -Path $inputFile -Encoding UTF8

# 计算SAscore
$results = @()
foreach ($row in $data) {
    # 找到SMILES列
    $smiles = $null
    foreach ($prop in $row.PSObject.Properties) {
        if ($prop.Name -like "*smiles*") {
            $smiles = $prop.Value
            break
        }
    }
    
    if ($smiles) {
        $sascore = Calculate-SAScore $smiles
        $row | Add-Member -MemberType NoteProperty -Name "SAscore" -Value $sascore -Force
    }
    $results += $row
}

# 保存结果
$results | Export-Csv -Path $outputFile -Encoding UTF8 -NoTypeInformation
Write-Host "成功! 已添加SAscore到文件: $outputFile"
Write-Host "共处理了 $($results.Count) 个分子"

# 显示统计信息
if ($results.Count -gt 0) {
    $scores = $results | ForEach-Object { [double]$_.SAscore }
    Write-Host "`nSAscore统计:"
    Write-Host "  最低SAscore (最易合成): $([Math]::Round(($scores | Measure-Object -Minimum).Minimum, 2))"
    Write-Host "  最高SAscore (最难合成): $([Math]::Round(($scores | Measure-Object -Maximum).Maximum, 2))"
    Write-Host "  平均SAscore: $([Math]::Round(($scores | Measure-Object -Average).Average, 2))"
    
    # 按SAscore排序显示前5个最易合成的分子
    $sorted = $results | Sort-Object { [double]$_.SAscore }
    Write-Host "`n前5个最易合成的分子 (按SAscore排序):"
    for ($i = 0; $i -lt [Math]::Min(5, $sorted.Count); $i++) {
        Write-Host "  $($i+1). SAscore=$($sorted[$i].SAscore)"
    }
}

# 同时也更新帕累托解编号映射文件
$mappingFile = "帕累托解编号映射.csv"
if (Test-Path $mappingFile) {
    $mappingData = Import-Csv -Path $mappingFile -Encoding UTF8
    foreach ($row in $mappingData) {
        $smiles = $null
        foreach ($prop in $row.PSObject.Properties) {
            if ($prop.Name -like "*smiles*") {
                $smiles = $prop.Value
                break
            }
        }
        if ($smiles) {
            $sascore = Calculate-SAScore $smiles
            $row | Add-Member -MemberType NoteProperty -Name "SAscore" -Value $sascore -Force
        }
    }
    $mappingData | Export-Csv -Path "帕累托解编号映射_含SAscore.csv" -Encoding UTF8 -NoTypeInformation
    Write-Host "`n也已更新编号映射文件: 帕累托解编号映射_含SAscore.csv"
}

Write-Host "`n完成!"
