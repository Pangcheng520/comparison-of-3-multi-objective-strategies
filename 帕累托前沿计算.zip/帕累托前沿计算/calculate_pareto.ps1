# 读取CSV文件
$data = Import-Csv -Path "虚拟分子预测结果_过滤后.csv" -Encoding UTF8
$totalCount = $data.Count
Write-Host "总样本数: $totalCount"

# 转换数据为数值数组
$objectives = @()
$smilesList = @()
foreach ($row in $data) {
    $smilesList += $row.smiles
    $obj = [PSCustomObject]@{
        Density = [double]$row."预测密度"
        Enthalpy = [double]$row."预测生成焓"
        Sensitivity = [double]$row."预测撞击感度"
        Index = $objectives.Count
    }
    $objectives += $obj
}

# 定义支配关系函数
function Test-Dominates {
    param([PSCustomObject]$p, [PSCustomObject]$q)
    # 密度和生成焓越大越好，撞击感度越小越好
    $cond1 = ($p.Density -ge $q.Density) -and ($p.Enthalpy -ge $q.Enthalpy) -and ($p.Sensitivity -le $q.Sensitivity)
    $cond2 = ($p.Density -gt $q.Density) -or ($p.Enthalpy -gt $q.Enthalpy) -or ($p.Sensitivity -lt $q.Sensitivity)
    return $cond1 -and $cond2
}

# 简单的帕累托前沿筛选方法
$paretoFront = @()

foreach ($p in $objectives) {
    $isDominated = $false
    foreach ($q in $objectives) {
        if ($p.Index -ne $q.Index -and (Test-Dominates $q $p)) {
            $isDominated = $true
            break
        }
    }
    if (-not $isDominated) {
        $paretoFront += $p
    }
}

Write-Host "`n帕累托前沿包含 $($paretoFront.Count) 个解"

# 保存帕累托前沿结果
$paretoData = @()
foreach ($p in $paretoFront) {
    $paretoData += [PSCustomObject]@{
        smiles = $smilesList[$p.Index]
        "预测密度" = $p.Density
        "预测生成焓" = $p.Enthalpy
        "预测撞击感度" = $p.Sensitivity
    }
}

$paretoData | Export-Csv -Path "帕累托前沿结果.csv" -Encoding UTF8 -NoTypeInformation
Write-Host "帕累托前沿结果已保存到: 帕累托前沿结果.csv"

# 保存作图数据 - 所有样本
$plotDataAll = @()
foreach ($obj in $objectives) {
    $plotDataAll += [PSCustomObject]@{
        密度 = $obj.Density
        生成焓 = $obj.Enthalpy
        撞击感度 = $obj.Sensitivity
    }
}
$plotDataAll | Export-Csv -Path "作图数据_所有样本.csv" -Encoding UTF8 -NoTypeInformation
Write-Host "所有样本作图数据已保存到: 作图数据_所有样本.csv"

# 保存作图数据 - 帕累托前沿
$plotDataPareto = @()
for ($i = 0; $i -lt $paretoFront.Count; $i++) {
    $p = $paretoFront[$i]
    $plotDataPareto += [PSCustomObject]@{
        编号 = "P$($i+1)"
        密度 = $p.Density
        生成焓 = $p.Enthalpy
        撞击感度 = $p.Sensitivity
        smiles = $smilesList[$p.Index]
    }
}
$plotDataPareto | Export-Csv -Path "作图数据_帕累托前沿.csv" -Encoding UTF8 -NoTypeInformation
Write-Host "帕累托前沿作图数据已保存到: 作图数据_帕累托前沿.csv"

# 保存帕累托解编号映射
$paretoMapping = @()
for ($i = 0; $i -lt $paretoFront.Count; $i++) {
    $p = $paretoFront[$i]
    $paretoMapping += [PSCustomObject]@{
        编号 = "P$($i+1)"
        smiles = $smilesList[$p.Index]
        "预测密度" = $p.Density
        "预测生成焓" = $p.Enthalpy
        "预测撞击感度" = $p.Sensitivity
    }
}
$paretoMapping | Export-Csv -Path "帕累托解编号映射.csv" -Encoding UTF8 -NoTypeInformation
Write-Host "帕累托解编号映射已保存到: 帕累托解编号映射.csv"

# 输出帕累托前沿样本信息
Write-Host "`n帕累托前沿样本详情:"
$paretoMapping | Format-Table -AutoSize

Write-Host "`n============================================================"
Write-Host "分析完成！生成的文件："
Write-Host "  - 帕累托前沿结果.csv"
Write-Host "  - 作图数据_所有样本.csv"
Write-Host "  - 作图数据_帕累托前沿.csv"
Write-Host "  - 帕累托解编号映射.csv"
Write-Host "============================================================"
