﻿import csv
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from matplotlib import cm

def dominates(p, q):
    """
    判断解p是否支配解q
    对于三个目标：
    - 预测密度：越大越好
    - 预测生成焓：越大越好
    - 预测撞击感度：越小越好
    """
    # 密度和生成焓越大越好，撞击感度越小越好
    condition1 = (p[0] >= q[0]) and (p[1] >= q[1]) and (p[2] <= q[2])
    condition2 = (p[0] > q[0]) or (p[1] > q[1]) or (p[2] < q[2])
    return condition1 and condition2

def non_dominated_sort(objectives):
    """
    非支配排序算法
    返回每个前沿的索引列表
    """
    n = len(objectives)
    S = [[] for _ in range(n)]  # 被每个解支配的解的集合
    n_dom = [0] * n  # 支配每个解的解的数量
    fronts = [[]]  # 前沿集合
    
    # 第一次遍历，计算每个解的支配关系
    for p in range(n):
        for q in range(n):
            if p != q:
                if dominates(objectives[p], objectives[q]):
                    S[p].append(q)
                elif dominates(objectives[q], objectives[p]):
                    n_dom[p] += 1
        
        if n_dom[p] == 0:
            fronts[0].append(p)
    
    # 计算后续的前沿
    i = 0
    while fronts[i]:
        next_front = []
        for p in fronts[i]:
            for q in S[p]:
                n_dom[q] -= 1
                if n_dom[q] == 0:
                    next_front.append(q)
        i += 1
        fronts.append(next_front)
    
    return fronts[:-1]  # 移除空的最后一个前沿

def save_plot_data(filename, data_dict):
    """保存作图数据到CSV文件"""
    with open(filename, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        # 写入表头
        headers = list(data_dict.keys())
        writer.writerow(headers)
        # 写入数据
        max_len = max(len(v) for v in data_dict.values())
        for i in range(max_len):
            row = []
            for key in headers:
                if i < len(data_dict[key]):
                    row.append(data_dict[key][i])
                else:
                    row.append('')
            writer.writerow(row)

def main():
    # 读取CSV文件
    input_file = '虚拟分子预测结果_过滤后.csv'
    data = []
    smiles_list = []
    
    with open(input_file, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        # 打印列名用于调试
        print("CSV列名:", reader.fieldnames)
        for row in reader:
            # 尝试获取列名，去除可能的空格
            keys = list(row.keys())
            # 查找对应的列
            smiles_col = None
            density_col = None
            enthalpy_col = None
            sensitivity_col = None
            
            for key in keys:
                cleaned_key = key.strip()
                if 'smiles' in cleaned_key.lower():
                    smiles_col = key
                elif '密度' in cleaned_key:
                    density_col = key
                elif '生成焓' in cleaned_key:
                    enthalpy_col = key
                elif '撞击感度' in cleaned_key:
                    sensitivity_col = key
            
            if smiles_col and density_col and enthalpy_col and sensitivity_col:
                smiles_list.append(row[smiles_col])
                data.append([
                    float(row[density_col]),
                    float(row[enthalpy_col]),
                    float(row[sensitivity_col])
                ])
            else:
                print(f"警告: 找不到所需列，行: {row}")
                print(f"可用列: {keys}")
    
    objectives = np.array(data)
    print(f"总样本数: {len(objectives)}")
    
    # 进行非支配排序
    fronts = non_dominated_sort(objectives)
    
    print(f"\n非支配排序结果:")
    for i, front in enumerate(fronts):
        print(f"前沿 {i+1}: {len(front)} 个解")
    
    # 获取帕累托前沿（第一个前沿）
    pareto_front_indices = fronts[0]
    pareto_objectives = objectives[pareto_front_indices]
    pareto_smiles = [smiles_list[i] for i in pareto_front_indices]
    
    print(f"\n帕累托前沿包含 {len(pareto_front_indices)} 个解")
    
    # 保存帕累托前沿结果
    output_file = '帕累托前沿结果.csv'
    with open(output_file, 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['smiles', '预测密度', '预测生成焓', '预测撞击感度'])
        for i in pareto_front_indices:
            writer.writerow([
                smiles_list[i],
                objectives[i, 0],
                objectives[i, 1],
                objectives[i, 2]
            ])
    print(f"帕累托前沿结果已保存到: {output_file}")
    
    # 保存作图数据 - 所有样本
    plot_data_all = {
        '密度': objectives[:, 0].tolist(),
        '生成焓': objectives[:, 1].tolist(),
        '撞击感度': objectives[:, 2].tolist()
    }
    save_plot_data('作图数据_所有样本.csv', plot_data_all)
    print(f"所有样本作图数据已保存到: 作图数据_所有样本.csv")
    
    # 保存作图数据 - 帕累托前沿
    plot_data_pareto = {
        '密度': pareto_objectives[:, 0].tolist(),
        '生成焓': pareto_objectives[:, 1].tolist(),
        '撞击感度': pareto_objectives[:, 2].tolist(),
        'smiles': pareto_smiles
    }
    save_plot_data('作图数据_帕累托前沿.csv', plot_data_pareto)
    print(f"帕累托前沿作图数据已保存到: 作图数据_帕累托前沿.csv")
    
    # 保存所有前沿的统计数据
    front_stats = []
    for i, front in enumerate(fronts):
        front_obj = objectives[front]
        front_stats.append({
            '前沿编号': i + 1,
            '解数量': len(front),
            '密度_均值': np.mean(front_obj[:, 0]),
            '密度_最小值': np.min(front_obj[:, 0]),
            '密度_最大值': np.max(front_obj[:, 0]),
            '生成焓_均值': np.mean(front_obj[:, 1]),
            '生成焓_最小值': np.min(front_obj[:, 1]),
            '生成焓_最大值': np.max(front_obj[:, 1]),
            '撞击感度_均值': np.mean(front_obj[:, 2]),
            '撞击感度_最小值': np.min(front_obj[:, 2]),
            '撞击感度_最大值': np.max(front_obj[:, 2])
        })
    
    with open('前沿统计数据.csv', 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=front_stats[0].keys())
        writer.writeheader()
        writer.writerows(front_stats)
    print(f"前沿统计数据已保存到: 前沿统计数据.csv")
    
    # 设置中文字体
    plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'Arial Unicode MS']
    plt.rcParams['axes.unicode_minus'] = False
    
    # 可视化1: 3D散点图 - 主图
    fig1 = plt.figure(figsize=(14, 10))
    ax1 = fig1.add_subplot(111, projection='3d')
    
    # 绘制所有样本
    scatter_all = ax1.scatter(objectives[:, 0], objectives[:, 1], objectives[:, 2], 
                c='steelblue', label='所有样本', alpha=0.4, s=50, edgecolors='none')
    
    # 绘制帕累托前沿
    scatter_pareto = ax1.scatter(pareto_objectives[:, 0], pareto_objectives[:, 1], pareto_objectives[:, 2], 
                c='crimson', label='帕累托前沿', s=120, edgecolors='black', linewidths=2, marker='D')
    
    # 为帕累托前沿点添加标签
    for i, (x, y, z) in enumerate(pareto_objectives):
        ax1.text(x, y, z, f'P{i+1}', fontsize=8, fontweight='bold')
    
    ax1.set_xlabel('预测密度', fontsize=12, fontweight='bold')
    ax1.set_ylabel('预测生成焓', fontsize=12, fontweight='bold')
    ax1.set_zlabel('预测撞击感度', fontsize=12, fontweight='bold')
    ax1.set_title('帕累托前沿 - 3D可视化', fontsize=16, fontweight='bold', pad=20)
    ax1.legend(fontsize=11, loc='upper left')
    ax1.grid(True, alpha=0.3)
    ax1.view_init(elev=20, azim=45)
    
    plt.tight_layout()
    plt.savefig('图1_帕累托前沿3D视图.png', dpi=300, bbox_inches='tight')
    print(f"图1已保存到: 图1_帕累托前沿3D视图.png")
    plt.close()
    
    # 可视化2: 多个2D投影图
    fig2 = plt.figure(figsize=(18, 12))
    
    # 子图1: 密度 vs 生成焓
    ax2 = fig2.add_subplot(231)
    ax2.scatter(objectives[:, 0], objectives[:, 1], c='steelblue', label='所有样本', alpha=0.5, s=40)
    ax2.scatter(pareto_objectives[:, 0], pareto_objectives[:, 1], 
                c='crimson', label='帕累托前沿', s=80, edgecolors='black', marker='D')
    ax2.set_xlabel('预测密度', fontsize=11, fontweight='bold')
    ax2.set_ylabel('预测生成焓', fontsize=11, fontweight='bold')
    ax2.set_title('密度 vs 生成焓', fontsize=13, fontweight='bold')
    ax2.legend(fontsize=10)
    ax2.grid(True, alpha=0.3)
    
    # 子图2: 密度 vs 撞击感度
    ax3 = fig2.add_subplot(232)
    ax3.scatter(objectives[:, 0], objectives[:, 2], c='steelblue', label='所有样本', alpha=0.5, s=40)
    ax3.scatter(pareto_objectives[:, 0], pareto_objectives[:, 2], 
                c='crimson', label='帕累托前沿', s=80, edgecolors='black', marker='D')
    ax3.set_xlabel('预测密度', fontsize=11, fontweight='bold')
    ax3.set_ylabel('预测撞击感度', fontsize=11, fontweight='bold')
    ax3.set_title('密度 vs 撞击感度', fontsize=13, fontweight='bold')
    ax3.legend(fontsize=10)
    ax3.grid(True, alpha=0.3)
    ax3.invert_yaxis()
    
    # 子图3: 生成焓 vs 撞击感度
    ax4 = fig2.add_subplot(233)
    ax4.scatter(objectives[:, 1], objectives[:, 2], c='steelblue', label='所有样本', alpha=0.5, s=40)
    ax4.scatter(pareto_objectives[:, 1], pareto_objectives[:, 2], 
                c='crimson', label='帕累托前沿', s=80, edgecolors='black', marker='D')
    ax4.set_xlabel('预测生成焓', fontsize=11, fontweight='bold')
    ax4.set_ylabel('预测撞击感度', fontsize=11, fontweight='bold')
    ax4.set_title('生成焓 vs 撞击感度', fontsize=13, fontweight='bold')
    ax4.legend(fontsize=10)
    ax4.grid(True, alpha=0.3)
    ax4.invert_yaxis()
    
    # 子图4: 密度分布直方图
    ax5 = fig2.add_subplot(234)
    ax5.hist(objectives[:, 0], bins=20, alpha=0.7, color='steelblue', label='所有样本')
    ax5.hist(pareto_objectives[:, 0], bins=10, alpha=0.7, color='crimson', label='帕累托前沿')
    ax5.set_xlabel('预测密度', fontsize=11, fontweight='bold')
    ax5.set_ylabel('频数', fontsize=11, fontweight='bold')
    ax5.set_title('密度分布直方图', fontsize=13, fontweight='bold')
    ax5.legend(fontsize=10)
    ax5.grid(True, alpha=0.3, axis='y')
    
    # 子图5: 生成焓分布直方图
    ax6 = fig2.add_subplot(235)
    ax6.hist(objectives[:, 1], bins=20, alpha=0.7, color='steelblue', label='所有样本')
    ax6.hist(pareto_objectives[:, 1], bins=10, alpha=0.7, color='crimson', label='帕累托前沿')
    ax6.set_xlabel('预测生成焓', fontsize=11, fontweight='bold')
    ax6.set_ylabel('频数', fontsize=11, fontweight='bold')
    ax6.set_title('生成焓分布直方图', fontsize=13, fontweight='bold')
    ax6.legend(fontsize=10)
    ax6.grid(True, alpha=0.3, axis='y')
    
    # 子图6: 撞击感度分布直方图
    ax7 = fig2.add_subplot(236)
    ax7.hist(objectives[:, 2], bins=20, alpha=0.7, color='steelblue', label='所有样本')
    ax7.hist(pareto_objectives[:, 2], bins=10, alpha=0.7, color='crimson', label='帕累托前沿')
    ax7.set_xlabel('预测撞击感度', fontsize=11, fontweight='bold')
    ax7.set_ylabel('频数', fontsize=11, fontweight='bold')
    ax7.set_title('撞击感度分布直方图', fontsize=13, fontweight='bold')
    ax7.legend(fontsize=10)
    ax7.grid(True, alpha=0.3, axis='y')
    
    plt.tight_layout()
    plt.savefig('图2_多维度分析图.png', dpi=300, bbox_inches='tight')
    print(f"图2已保存到: 图2_多维度分析图.png")
    plt.close()
    
    # 可视化3: 所有前沿层级图
    fig3 = plt.figure(figsize=(16, 10))
    
    # 3D图显示所有前沿
    ax8 = fig3.add_subplot(121, projection='3d')
    colors = cm.rainbow(np.linspace(0, 1, len(fronts)))
    
    for i, (front, color) in enumerate(zip(fronts, colors)):
        front_obj = objectives[front]
        label = f'前沿 {i+1} ({len(front)}个)'
        alpha = 1.0 if i == 0 else 0.6
        size = 100 if i == 0 else 50
        ax8.scatter(front_obj[:, 0], front_obj[:, 1], front_obj[:, 2], 
                   c=[color], label=label, alpha=alpha, s=size, edgecolors='black', linewidths=0.5)
    
    ax8.set_xlabel('预测密度', fontsize=11, fontweight='bold')
    ax8.set_ylabel('预测生成焓', fontsize=11, fontweight='bold')
    ax8.set_zlabel('预测撞击感度', fontsize=11, fontweight='bold')
    ax8.set_title('所有非支配前沿 - 3D视图', fontsize=14, fontweight='bold')
    ax8.legend(fontsize=9, loc='upper left', bbox_to_anchor=(1.05, 1))
    ax8.grid(True, alpha=0.3)
    ax8.view_init(elev=25, azim=50)
    
    # 2D投影显示前沿层级
    ax9 = fig3.add_subplot(122)
    for i, (front, color) in enumerate(zip(fronts, colors)):
        front_obj = objectives[front]
        label = f'前沿 {i+1}'
        alpha = 1.0 if i == 0 else 0.6
        size = 80 if i == 0 else 40
        ax9.scatter(front_obj[:, 0], front_obj[:, 1], c=[color], label=label, alpha=alpha, s=size)
    
    ax9.set_xlabel('预测密度', fontsize=11, fontweight='bold')
    ax9.set_ylabel('预测生成焓', fontsize=11, fontweight='bold')
    ax9.set_title('所有非支配前沿 - 密度vs生成焓', fontsize=14, fontweight='bold')
    ax9.legend(fontsize=9, loc='upper right')
    ax9.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('图3_所有前沿层级图.png', dpi=300, bbox_inches='tight')
    print(f"图3已保存到: 图3_所有前沿层级图.png")
    plt.close()
    
    # 可视化4: 帕累托前沿详细分析
    fig4 = plt.figure(figsize=(16, 10))
    
    # 子图1: 带连线的帕累托前沿（密度 vs 生成焓）
    ax10 = fig4.add_subplot(221)
    # 按密度排序后连线
    sorted_idx = np.argsort(pareto_objectives[:, 0])
    sorted_pareto = pareto_objectives[sorted_idx]
    ax10.plot(sorted_pareto[:, 0], sorted_pareto[:, 1], 'crimson', linestyle='--', linewidth=2, alpha=0.7, label='帕累托曲线')
    ax10.scatter(pareto_objectives[:, 0], pareto_objectives[:, 1], 
                c='crimson', s=100, edgecolors='black', marker='D', zorder=5)
    # 添加标签
    for i, (x, y) in enumerate(zip(pareto_objectives[:, 0], pareto_objectives[:, 1])):
        ax10.annotate(f'P{i+1}', (x, y), xytext=(5, 5), textcoords='offset points', fontsize=9)
    ax10.set_xlabel('预测密度', fontsize=11, fontweight='bold')
    ax10.set_ylabel('预测生成焓', fontsize=11, fontweight='bold')
    ax10.set_title('帕累托曲线 - 密度vs生成焓', fontsize=13, fontweight='bold')
    ax10.legend(fontsize=10)
    ax10.grid(True, alpha=0.3)
    
    # 子图2: 带连线的帕累托前沿（生成焓 vs 撞击感度）
    ax11 = fig4.add_subplot(222)
    # 按生成焓排序后连线
    sorted_idx2 = np.argsort(pareto_objectives[:, 1])
    sorted_pareto2 = pareto_objectives[sorted_idx2]
    ax11.plot(sorted_pareto2[:, 1], sorted_pareto2[:, 2], 'crimson', linestyle='--', linewidth=2, alpha=0.7, label='帕累托曲线')
    ax11.scatter(pareto_objectives[:, 1], pareto_objectives[:, 2], 
                c='crimson', s=100, edgecolors='black', marker='D', zorder=5)
    # 添加标签
    for i, (x, y) in enumerate(zip(pareto_objectives[:, 1], pareto_objectives[:, 2])):
        ax11.annotate(f'P{i+1}', (x, y), xytext=(5, 5), textcoords='offset points', fontsize=9)
    ax11.set_xlabel('预测生成焓', fontsize=11, fontweight='bold')
    ax11.set_ylabel('预测撞击感度', fontsize=11, fontweight='bold')
    ax11.set_title('帕累托曲线 - 生成焓vs撞击感度', fontsize=13, fontweight='bold')
    ax11.legend(fontsize=10)
    ax11.grid(True, alpha=0.3)
    ax11.invert_yaxis()
    
    # 子图3: 平行坐标图
    ax12 = fig4.add_subplot(223)
    # 归一化数据用于平行坐标
    normalized = np.zeros_like(pareto_objectives)
    for i in range(3):
        normalized[:, i] = (pareto_objectives[:, i] - np.min(objectives[:, i])) / (np.max(objectives[:, i]) - np.min(objectives[:, i]))
    
    for i in range(len(normalized)):
        ax12.plot([0, 1, 2], normalized[i], marker='o', linewidth=2, markersize=6, label=f'P{i+1}', alpha=0.8)
    
    ax12.set_xticks([0, 1, 2])
    ax12.set_xticklabels(['密度\n(归一化)', '生成焓\n(归一化)', '撞击感度\n(归一化)'], fontsize=10, fontweight='bold')
    ax12.set_ylabel('归一化值', fontsize=11, fontweight='bold')
    ax12.set_title('平行坐标图 - 帕累托前沿', fontsize=13, fontweight='bold')
    ax12.legend(fontsize=8, ncol=3, loc='upper center', bbox_to_anchor=(0.5, -0.15))
    ax12.grid(True, alpha=0.3)
    
    # 子图4: 雷达图（选取前5个帕累托解）
    ax13 = fig4.add_subplot(224, projection='polar')
    categories = ['密度', '生成焓', '1/撞击感度']
    N = len(categories)
    angles = [n / float(N) * 2 * np.pi for n in range(N)]
    angles += angles[:1]
    
    # 归一化数据，撞击感度取倒数（因为越小越好）
    display_count = min(5, len(pareto_objectives))
    for i in range(display_count):
        values = [
            (pareto_objectives[i, 0] - np.min(objectives[:, 0])) / (np.max(objectives[:, 0]) - np.min(objectives[:, 0])),
            (pareto_objectives[i, 1] - np.min(objectives[:, 1])) / (np.max(objectives[:, 1]) - np.min(objectives[:, 1])),
            # 撞击感度归一化并取倒数
            (np.max(objectives[:, 2]) - pareto_objectives[i, 2]) / (np.max(objectives[:, 2]) - np.min(objectives[:, 2]))
        ]
        values += values[:1]
        ax13.plot(angles, values, linewidth=2, marker='o', label=f'P{i+1}')
        ax13.fill(angles, values, alpha=0.1)
    
    ax13.set_xticks(angles[:-1])
    ax13.set_xticklabels(categories, fontsize=10, fontweight='bold')
    ax13.set_title('雷达图 - 帕累托解对比', fontsize=13, fontweight='bold', pad=20)
    ax13.legend(fontsize=10, loc='upper right', bbox_to_anchor=(1.3, 1.1))
    ax13.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig('图4_帕累托前沿详细分析.png', dpi=300, bbox_inches='tight')
    print(f"图4已保存到: 图4_帕累托前沿详细分析.png")
    plt.close()
    
    # 保存帕累托前沿的编号映射
    with open('帕累托解编号映射.csv', 'w', encoding='utf-8', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['编号', 'smiles', '预测密度', '预测生成焓', '预测撞击感度'])
        for i, idx in enumerate(pareto_front_indices):
            writer.writerow([
                f'P{i+1}',
                smiles_list[idx],
                objectives[idx, 0],
                objectives[idx, 1],
                objectives[idx, 2]
            ])
    print(f"帕累托解编号映射已保存到: 帕累托解编号映射.csv")
    
    print(f"\n{'='*60}")
    print(f"所有分析完成！共生成了以下文件：")
    print(f"  - 帕累托前沿结果.csv")
    print(f"  - 作图数据_所有样本.csv")
    print(f"  - 作图数据_帕累托前沿.csv")
    print(f"  - 前沿统计数据.csv")
    print(f"  - 帕累托解编号映射.csv")
    print(f"  - 图1_帕累托前沿3D视图.png")
    print(f"  - 图2_多维度分析图.png")
    print(f"  - 图3_所有前沿层级图.png")
    print(f"  - 图4_帕累托前沿详细分析.png")
    print(f"{'='*60}")

if __name__ == '__main__':
    main()
