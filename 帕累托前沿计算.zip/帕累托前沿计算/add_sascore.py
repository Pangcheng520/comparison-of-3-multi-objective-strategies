import csv
import math
import os

def calculate_sascore(smiles):
    """
    简化版SAscore计算（基于常见的结构特征估算）
    真实的SAscore需要RDKit库，但这里提供一个简化估算版本
    返回值范围：1（易合成）- 10（难合成）
    """
    if not smiles or len(smiles.strip()) == 0:
        return 5.0
    
    s = smiles.strip()
    
    # 基础分数
    score = 5.0
    
    # 1. 分子量/分子大小估算（基于SMILES长度）
    length = len(s)
    if length < 30:
        score -= 1.0
    elif length > 80:
        score += 2.0
    
    # 2. 环系统复杂度
    ring_count = s.count('1') + s.count('2') + s.count('3') + s.count('4')
    if ring_count > 4:
        score += 1.5
    if ring_count > 6:
        score += 1.0
    
    # 3. 杂原子数量
    hetero_count = s.count('N') + s.count('O') + s.count('S') + s.count('P') + s.count('F') + s.count('Cl') + s.count('Br') + s.count('I')
    if hetero_count > 8:
        score += 1.0
    
    # 4. 复杂官能团
    complex_groups = ['C#N', 'C#C', 'N=O', 'S(=O)', 'P(=O)', 'B(', 'Si']
    for group in complex_groups:
        if group in s:
            score += 0.5
    
    # 5. 立体中心指示
    if '@' in s:
        score += 0.5
    
    # 限制范围在1-10
    score = max(1.0, min(10.0, score))
    
    return round(score, 2)

def main():
    # 读取帕累托前沿结果
    input_file = '帕累托前沿结果.csv'
    output_file = '帕累托前沿结果_含SAscore.csv'
    
    if not os.path.exists(input_file):
        print(f"错误: 找不到文件 {input_file}")
        return
    
    data = []
    
    with open(input_file, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames
        
        print("列名:", fieldnames)
        
        for row in reader:
            # 获取SMILES
            smiles = None
            for key in row.keys():
                if 'smiles' in key.lower():
                    smiles = row[key]
                    break
            
            if not smiles:
                print(f"警告: 找不到SMILES列，行: {row}")
                continue
            
            # 计算SAscore
            sascore = calculate_sascore(smiles)
            
            # 添加到行数据
            row['SAscore'] = sascore
            data.append(row)
    
    # 添加SAscore到字段名
    if 'SAscore' not in fieldnames:
        fieldnames = fieldnames + ['SAscore']
    
    # 保存结果
    with open(output_file, 'w', encoding='utf-8', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(data)
    
    print(f"\n成功! 已添加SAscore到文件: {output_file}")
    print(f"共处理了 {len(data)} 个分子")
    
    # 显示统计信息
    if data:
        scores = [float(row['SAscore']) for row in data]
        print(f"\nSAscore统计:")
        print(f"  最低SAscore (最易合成): {min(scores):.2f}")
        print(f"  最高SAscore (最难合成): {max(scores):.2f}")
        print(f"  平均SAscore: {sum(scores)/len(scores):.2f}")
        
        # 按SAscore排序显示前5个最易合成的分子
        sorted_data = sorted(data, key=lambda x: float(x['SAscore']))
        print(f"\n前5个最易合成的分子 (按SAscore排序):")
        for i, row in enumerate(sorted_data[:5]):
            print(f"  {i+1}. SAscore={row['SAscore']}")
    
    # 同时也更新帕累托解编号映射文件
    mapping_file = '帕累托解编号映射.csv'
    if os.path.exists(mapping_file):
        mapping_data = []
        with open(mapping_file, 'r', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            mapping_fieldnames = reader.fieldnames
            
            for row in reader:
                smiles = None
                for key in row.keys():
                    if 'smiles' in key.lower():
                        smiles = row[key]
                        break
                if smiles:
                    sascore = calculate_sascore(smiles)
                    row['SAscore'] = sascore
                mapping_data.append(row)
        
        if 'SAscore' not in mapping_fieldnames:
            mapping_fieldnames = mapping_fieldnames + ['SAscore']
        
        with open('帕累托解编号映射_含SAscore.csv', 'w', encoding='utf-8', newline='') as f:
            writer = csv.DictWriter(f, fieldnames=mapping_fieldnames)
            writer.writeheader()
            writer.writerows(mapping_data)
        
        print(f"\n也已更新编号映射文件: 帕累托解编号映射_含SAscore.csv")

if __name__ == '__main__':
    main()
